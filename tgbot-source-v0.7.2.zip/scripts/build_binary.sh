#!/usr/bin/env bash
# بناء telegram-bot-api من المصدر على commit محدد.
# الاستخدام: bash scripts/build_binary.sh <مجلد_الإخراج>      (اختياري: TBA_REF=<commit>)
set -euo pipefail
OUT="$(realpath -m "${1:-./out}")"
REF="${TBA_REF:-7232881b39dfcd048a0d569f1983c5184249ee05}"   # Bot API 10.4 (يدعم style للأزرار)
SUDO=""; [ "$(id -u)" -ne 0 ] && SUDO="sudo"

$SUDO apt-get update -qq
$SUDO env DEBIAN_FRONTEND=noninteractive apt-get install -y -qq make git zlib1g-dev libssl-dev gperf cmake g++

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
git clone --recursive https://github.com/tdlib/telegram-bot-api.git "$WORK/src"
cd "$WORK/src"
git checkout "$REF"
git submodule update --init --recursive

# TDLib بيستهلك ~3GB RAM لكل عملية compile: نحدد التوازي بالـ RAM مش بالـ CPU بس (OOM = "Killed signal")
MEM_GB="$(awk '/MemAvailable/{printf "%d", $2/1024/1024}' /proc/meminfo)"
JOBS="$(nproc)"; BYMEM=$(( MEM_GB / 3 ))
if [ "$BYMEM" -lt 1 ]; then BYMEM=1; fi
if [ "$JOBS" -gt "$BYMEM" ]; then JOBS="$BYMEM"; fi
if [ "$JOBS" -gt 4 ]; then JOBS=4; fi
echo "ℹ️ cpu=$(nproc) mem_available=${MEM_GB}GB → jobs=$JOBS | $(g++ --version | head -1) | $(cmake --version | head -1)"
mkdir build && cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
cmake --build . --target telegram-bot-api -j"$JOBS"

mkdir -p "$OUT"
cp telegram-bot-api "$OUT/telegram-bot-api"
strip "$OUT/telegram-bot-api" || true
"$OUT/telegram-bot-api" --version
echo "✅ built: $OUT/telegram-bot-api"
