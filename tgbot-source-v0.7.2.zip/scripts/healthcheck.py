"""فحص سريع من الـ notebook: python scripts/healthcheck.py"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import Config
from core import server

c = Config.from_env()
print("السيرفر المحلي:", "✅ شغّال" if server.is_alive(c) else "❌ واقف")
print("الـ binary:", server.binary_version(c.binary) or "❌ مش موجود")
