"""الفيديو (FFmpeg): ضغط، قص، دمج، فصل صوت، تغيير الحاوية + NVENC مع fallback تلقائي لـ CPU."""
from __future__ import annotations

import os
from pathlib import Path

from core.ffrun import FFmpegError, ff
from core.queue import UserError

# ---------- المشفّرات ----------
def venc(codec: str, gpu: bool, crf: int, preset: str = "veryfast") -> list:
    if codec == "h265":
        if gpu:
            return ["-c:v", "hevc_nvenc", "-preset", "p5", "-rc", "vbr", "-cq", str(crf), "-b:v", "0",
                    "-tag:v", "hvc1", "-pix_fmt", "yuv420p"]
        return ["-c:v", "libx265", "-preset", preset, "-crf", str(crf), "-tag:v", "hvc1", "-pix_fmt", "yuv420p"]
    if gpu:
        return ["-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr", "-cq", str(crf), "-b:v", "0", "-pix_fmt", "yuv420p"]
    return ["-c:v", "libx264", "-preset", preset, "-crf", str(crf), "-pix_fmt", "yuv420p"]


async def encode_with_fallback(rc, build, gpu: bool, duration, label):
    """build(gpu)->args. لو NVENC فشل في نص المهمة نكمّل على CPU ونبلّغ المستخدم."""
    if gpu:
        try:
            await ff(rc, build(True), duration, label + " ⚡GPU")
            return True
        except UserError:
            rc.notes.append("⚠️ الـ GPU (NVENC) فشل في نص المهمة، فكمّلت على CPU.")
            rc.check_cancel()
    await ff(rc, build(False), duration, label)
    return False


def gpu_available() -> bool:
    """NVENC اتجرّب فعليًا وقت bootstrap (health.json)."""
    import json
    try:
        work = Path(os.environ.get("TGBOT_WORK", "/content/tgwork"))
        return json.loads((work / "health.json").read_text()).get("gpu") == "nvenc"
    except Exception:
        return False


# ---------- التوافق ----------
MP4_V = {"h264", "hevc", "mpeg4", "av1", "mjpeg"}
MP4_A = {"aac", "mp3", "ac3", "eac3", "alac", "opus"}
CONTAINERS = {
    "mp4": {"ext": ".mp4", "v": MP4_V, "a": MP4_A},
    "mov": {"ext": ".mov", "v": MP4_V - {"av1"}, "a": MP4_A - {"opus"}},
    "mkv": {"ext": ".mkv", "v": None, "a": None},
    "webm": {"ext": ".webm", "v": {"vp8", "vp9", "av1"}, "a": {"opus", "vorbis"}},
}


def copy_plan(probe: dict, target: str):
    """(copy_video, copy_audio) لو الحاوية الهدف تقبل الكودك الحالي."""
    c = CONTAINERS[target]
    v, a = probe.get("vcodec"), probe.get("acodec")
    cv = c["v"] is None or (v in c["v"])
    ca = (a is None) or c["a"] is None or (a in c["a"])
    return cv, ca


# ---------- قص ----------
async def cut(rc, src: Path, dst: Path, start: float, dur: float, precise: bool, gpu: bool):
    pr = rc.probe
    base = ["-ss", f"{start:.3f}", "-i", src, "-t", f"{dur:.3f}", "-map", "0:v:0", "-map", "0:a?", "-map_metadata", "0"]
    if not precise:
        await ff(rc, [*base, "-c", "copy", "-avoid_negative_ts", "make_zero", dst], dur, "✂️ قص سريع")
        return
    crf = 20
    ac = ["-c:a", "aac", "-b:a", "160k"] if dst.suffix != ".webm" else ["-c:a", "libopus", "-b:a", "128k"]
    await encode_with_fallback(rc, lambda g: [*base, *venc("h264", g, crf), *ac, "-movflags", "+faststart", dst],
                               gpu, dur, "🎯 قص دقيق")


# ---------- ضغط ----------
def scale_filter(height: int):
    return ["-vf", f"scale=-2:{height}"] if height else []


async def compress(rc, src, dst, height, codec, crf, audio, gpu, duration):
    ac = ["-c:a", "copy"] if audio == "copy" else ["-c:a", "aac", "-b:a", f"{audio}k"]

    def build(g):
        return ["-i", src, "-map", "0:v:0", "-map", "0:a?", "-map_metadata", "0", *scale_filter(height),
                *venc(codec, g, crf), *ac, "-movflags", "+faststart", dst]
    return await encode_with_fallback(rc, build, gpu, duration, "🗜 بضغط")


# ---------- دمج ----------
def _sig(p):
    return (p.get("vcodec"), p.get("width"), p.get("height"), round(p.get("fps") or 0), p.get("acodec"),
            p.get("sample_rate"), p.get("channels"), p.get("ext"))


def merge_compat(probes: list):
    """(متطابقين؟, سبب الاختلاف)"""
    first = _sig(probes[0])
    names = ("الكودك", "العرض", "الارتفاع", "FPS", "كودك الصوت", "Sample rate", "القنوات", "الصيغة")
    for p in probes[1:]:
        s = _sig(p)
        diff = [n for n, a, b in zip(names, first, s) if a != b]
        if diff:
            return False, "، ".join(diff[:3])
    return True, ""


def _list_line(p: Path) -> str:
    return "file '" + str(p).replace("'", "'\\''") + "'\n"


async def merge(rc, files: list, dst: Path, probes: list, mode: str, gpu: bool):
    total = sum((p.get("duration") or 0) for p in probes) or None
    if mode == "copy":
        lst = rc.jobdir / "list.txt"
        lst.write_text("".join(_list_line(f) for f in files), encoding="utf-8")
        await ff(rc, ["-f", "concat", "-safe", "0", "-i", lst, "-map", "0:v:0", "-map", "0:a?", "-c", "copy", dst],
                 total, "🧩 دمج سريع")
        return
    w, h = probes[0].get("width") or 1280, probes[0].get("height") or 720
    w, h = w - w % 2, h - h % 2
    fps = round(probes[0].get("fps") or 30) or 30
    with_audio = all(p.get("acodec") for p in probes)
    if not with_audio and any(p.get("acodec") for p in probes):
        rc.notes.append("⚠️ بعض الملفات من غير صوت، فالناتج اتعمل من غير صوت.")
    sr = probes[0].get("sample_rate") or 44100
    ins, fl, cat = [], [], ""
    for n, f in enumerate(files):
        ins += ["-i", f]
        fl.append(f"[{n}:v:0]scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,"
                  f"setsar=1,fps={fps},format=yuv420p[v{n}]")
        if with_audio:
            fl.append(f"[{n}:a:0]aformat=sample_fmts=fltp:sample_rates={sr}:channel_layouts=stereo[a{n}]")
            cat += f"[v{n}][a{n}]"
        else:
            cat += f"[v{n}]"
    chain = ";".join(fl) + ";" + cat + f"concat=n={len(files)}:v=1:a={1 if with_audio else 0}" + \
        ("[v][a]" if with_audio else "[v]")
    maps = ["-map", "[v]"] + (["-map", "[a]"] if with_audio else [])

    def build(g):
        return [*ins, "-filter_complex", chain, *maps, *venc("h264", g, 21),
                *(["-c:a", "aac", "-b:a", "160k"] if with_audio else []), "-movflags", "+faststart", dst]
    await encode_with_fallback(rc, build, gpu, total, "🧩 دمج بإعادة ترميز")


# ---------- فصل الصوت ----------
COPY_EXT = {"aac": ".m4a", "mp3": ".mp3", "opus": ".opus", "vorbis": ".ogg", "flac": ".flac", "ac3": ".ac3",
            "pcm_s16le": ".wav"}


# ---------- تغيير الحاوية ----------
async def remux(rc, src, dst, target, duration):
    c = CONTAINERS[target]
    cv, ca = copy_plan(rc.probe, target)
    maps = ["-map", "0"] if target == "mkv" else ["-map", "0:v:0", "-map", "0:a?"]
    if target == "webm":
        v = ["-c:v", "copy"] if cv else ["-c:v", "libvpx-vp9", "-crf", "32", "-b:v", "0", "-row-mt", "1", "-deadline", "good", "-cpu-used", "4"]
        a = ["-c:a", "copy"] if ca else ["-c:a", "libopus", "-b:a", "128k"]
    else:
        v = ["-c:v", "copy"] if cv else ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p"]
        a = ["-c:a", "copy"] if ca else ["-c:a", "aac", "-b:a", "192k"]
    extra = ["-movflags", "+faststart"] if target in ("mp4", "mov") else []
    await ff(rc, ["-i", src, *maps, "-map_metadata", "0", *v, *a, *extra, dst], duration,
             "📦 تغيير الصيغة" if (cv and ca) else "📦 تغيير الصيغة (مع ترميز)")
    if not (cv and ca):
        rc.notes.append("ℹ️ الكودك الأصلي مش متوافق مع الصيغة دي فاتعمل له ترميز "
                        + ("للصورة " if not cv else "") + ("والصوت" if not ca else ""))
    if target != "mkv" and rc.probe.get("lines") and any("ترجمات" in str(x[0]) for x in rc.probe["lines"]):
        rc.notes.append("ℹ️ الترجمات اتشالت (الصيغة دي مبتدعمهاش زي mkv).")
