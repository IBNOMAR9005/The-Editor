"""تحويلات: Word/PowerPoint/Excel → PDF (LibreOffice headless) وصور → PDF (img2pdf)."""
from __future__ import annotations

import asyncio
import os
import shutil
import subprocess
from pathlib import Path

from core.queue import UserError, run_cmd
from core.utils import esc, split_ext

PAGE_SIZES = {"a4": (210, 297), "letter": (215.9, 279.4)}


def soffice_bin() -> str | None:
    return shutil.which("soffice") or shutil.which("libreoffice")


async def ensure_libreoffice(rc):
    if soffice_bin():
        return
    await rc.say("⏳ بجهّز LibreOffice لأول مرة (٢-٤ دقايق، مرة واحدة في الجلسة)…", True)
    pre = [] if os.geteuid() == 0 else ["sudo"]
    env_cmd = ["env", "DEBIAN_FRONTEND=noninteractive"]
    await run_cmd(rc.job, *pre, *env_cmd, "apt-get", "update", "-qq", timeout=300)
    code, _o, err = await run_cmd(rc.job, *pre, *env_cmd, "apt-get", "install", "-y", "-qq", "--no-install-recommends",
                                  "libreoffice-writer", "libreoffice-impress", "libreoffice-calc", "fonts-noto-core",
                                  timeout=1500)
    await run_cmd(rc.job, "fc-cache", "-f", timeout=120)
    if code != 0 or not soffice_bin():
        raise UserError("تثبيت LibreOffice فشل.\n<code>" + esc((err or b"").decode("utf-8", "replace")[-300:]) + "</code>")


def _stage(src: Path, dstdir: Path, n: int) -> Path:
    dstdir.mkdir(exist_ok=True)
    p = dstdir / f"doc{n}{src.suffix.lower()}"
    try:
        os.link(src, p)
    except OSError:
        shutil.copyfile(src, p)
    return p


async def office_to_pdf(rc, src: Path, n: int = 0) -> Path:
    """بيحوّل ملف أوفيس لـ PDF جوه jobdir ويرجّع المسار."""
    await ensure_libreoffice(rc)
    staged = _stage(src, rc.jobdir / "office_in", n)
    outdir = rc.jobdir / "office_out"
    outdir.mkdir(exist_ok=True)
    profile = rc.jobdir / "lo_profile"
    await rc.say("📄 بحوّل لـ PDF بخطوط عربي…", True)
    code, _o, err = await run_cmd(rc.job, soffice_bin(), f"-env:UserInstallation=file://{profile}", "--headless",
                                  "--norestore", "--convert-to", "pdf", "--outdir", outdir, staged, timeout=900)
    pdf = outdir / (staged.stem + ".pdf")
    if code != 0 or not pdf.exists():
        raise UserError("LibreOffice مقدرش يحوّل الملف ده.\n<code>" + esc((err or b"").decode("utf-8", "replace")[-300:]) + "</code>")
    return pdf


def _prepare_image(p: Path, tmpdir: Path, i: int, quality: str) -> Path:
    from PIL import Image, ImageOps
    try:
        im = Image.open(p)
    except Exception:
        raise UserError(f"مقدرتش أقرأ الصورة «{esc(p.name)}» (صيغة غير مدعومة؟ جرّب JPG/PNG).") from None
    with im:
        has_alpha = im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info)
        needs = has_alpha or quality != "orig" or im.format not in ("JPEG", "PNG") or im.mode not in ("RGB", "L")
        if not needs and not im.getexif().get(274):   # لا alpha ولا دوران EXIF
            return p
        im = ImageOps.exif_transpose(im)
        if has_alpha:
            bg = Image.new("RGB", im.size, "white")
            bg.paste(im.convert("RGBA"), mask=im.convert("RGBA").split()[-1])
            im = bg
        else:
            im = im.convert("RGB")
        out = tmpdir / f"img{i}.jpg"
        if quality != "orig":
            im.thumbnail((2480, 3508))
        im.save(out, "JPEG", quality=80 if quality != "orig" else 95)
        return out


def _images_to_pdf(files, dst, size, orient, margin_mm, quality, tmpdir):
    import img2pdf
    tmpdir.mkdir(exist_ok=True)
    prepared = [_prepare_image(f, tmpdir, i, quality) for i, f in enumerate(files)]
    if size == "fit":
        layout = None
    else:
        w, h = (img2pdf.mm_to_pt(x) for x in PAGE_SIZES[size])
        if orient == "landscape":
            w, h = h, w
        m = img2pdf.mm_to_pt(margin_mm)
        layout = img2pdf.get_layout_fun((w, h), border=(m, m), fit=img2pdf.FitMode.into, auto_orient=(orient == "auto"))
    with open(dst, "wb") as f:
        f.write(img2pdf.convert([str(p) for p in prepared], layout_fun=layout) if layout
                else img2pdf.convert([str(p) for p in prepared]))


async def images_to_pdf(rc, files, dst, size, orient, margin_mm, quality):
    await rc.say(f"📄 بحوّل {len(files)} صورة لـ PDF…", True)
    try:
        await asyncio.to_thread(_images_to_pdf, files, dst, size, orient, margin_mm, quality, rc.jobdir / "img_tmp")
    except ImportError:
        raise UserError("img2pdf مش متثبّت — شغّل bootstrap تاني.") from None
