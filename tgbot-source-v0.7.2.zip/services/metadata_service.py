"""Metadata: قراءة/تعديل/حذف (ffmpeg للميديا، pikepdf للـ PDF، exiftool للصور وغيرها).
الحذف بيمسح بيانات الملف بس — مش محتواه."""
from __future__ import annotations

import asyncio
import json
import shutil
from pathlib import Path

from core.ffrun import ff
from core.queue import UserError, run_cmd
from core.utils import esc

FIELDS = {
    "audio": [("title", "العنوان"), ("artist", "الفنان"), ("album", "الألبوم"), ("date", "التاريخ"),
              ("genre", "النوع"), ("track", "رقم التراك"), ("comment", "تعليق")],
    "video": [("title", "العنوان"), ("artist", "المؤلف/القناة"), ("date", "التاريخ"), ("comment", "تعليق")],
    "pdf": [("title", "العنوان"), ("author", "المؤلف"), ("subject", "الموضوع"), ("keywords", "كلمات مفتاحية")],
    "image": [("title", "العنوان"), ("artist", "المصوّر"), ("description", "الوصف"), ("date", "التاريخ")],
}
LABELS = {k: v for fs in FIELDS.values() for k, v in fs}
COVER_OK = {".mp3", ".m4a", ".flac"}
PDF_KEYS = {"title": "/Title", "author": "/Author", "subject": "/Subject", "keywords": "/Keywords"}
EXIF_KEYS = {"title": "XMP-dc:Title", "artist": "Artist", "description": "ImageDescription", "date": "DateTimeOriginal"}


# ---------- PDF ----------
def pdf_fonts(pdf) -> list:
    """[(اسم الخط, مدمج؟)] — عرض فقط (الخطوط مش metadata بتتعدّل)."""
    seen = {}
    for page in list(pdf.pages)[:25]:
        try:
            fonts = page.Resources.get("/Font", {})
        except Exception:
            continue
        for _k, f in fonts.items():
            try:
                name = str(f.get("/BaseFont", "?")).lstrip("/").split("+")[-1]
                desc = f.get("/FontDescriptor")
                if desc is None and "/DescendantFonts" in f:
                    desc = f.DescendantFonts[0].get("/FontDescriptor")
                emb = bool(desc is not None and any(k in desc for k in ("/FontFile", "/FontFile2", "/FontFile3")))
                seen[name] = seen.get(name, False) or emb
            except Exception:
                continue
    return sorted(seen.items())


def _pdf_read(path) -> dict:
    import pikepdf
    out = {}
    with pikepdf.open(str(path)) as pdf:
        for k, pk in PDF_KEYS.items():
            if pk in pdf.docinfo:
                out[k] = str(pdf.docinfo[pk])
    return out


def _pdf_write(src, dst, changes: dict):
    import pikepdf
    with pikepdf.open(str(src)) as pdf:
        for k, v in changes.items():
            pk = PDF_KEYS[k]
            if v:
                pdf.docinfo[pk] = v
            elif pk in pdf.docinfo:
                del pdf.docinfo[pk]
        try:   # لو فيه XMP قديم بيغلب الـ docinfo في بعض القرّاء — نزامنه
            with pdf.open_metadata(set_pikepdf_as_editor=False) as m:
                for k, v in changes.items():
                    key = {"title": "dc:title", "author": "dc:creator", "subject": "dc:description",
                           "keywords": "pdf:Keywords"}[k]
                    if v:
                        m[key] = [v] if key == "dc:creator" else v
                    elif key in m:
                        del m[key]
        except Exception:
            pass
        pdf.save(str(dst))


def _pdf_strip(src, dst):
    import pikepdf
    with pikepdf.open(str(src)) as pdf:
        for k in list(pdf.docinfo.keys()):
            del pdf.docinfo[k]
        if "/Metadata" in pdf.Root:
            del pdf.Root["/Metadata"]
        for page in pdf.pages:
            for k in ("/Metadata", "/PieceInfo"):
                if k in page:
                    del page[k]
        pdf.save(str(dst))


# ---------- exiftool ----------
async def _exif_json(rc_or_job, path) -> dict:
    code, out, _e = await run_cmd(rc_or_job, "exiftool", "-j", "-G1", "-s", str(path), timeout=60)
    if code != 0:
        return {}
    try:
        return json.loads(out.decode("utf-8", "replace"))[0]
    except Exception:
        return {}


async def _ffprobe_tags(job, path) -> dict:
    code, out, _e = await run_cmd(job, "ffprobe", "-v", "error", "-print_format", "json", "-show_format", str(path), timeout=60)
    if code != 0:
        return {}
    try:
        return {k.lower(): str(v) for k, v in (json.loads(out)["format"].get("tags") or {}).items()}
    except Exception:
        return {}


async def read_meta(job, path, kind: str) -> dict:
    """القيم القابلة للتعديل فقط: {key: value}."""
    if kind in ("audio", "video"):
        tags = await _ffprobe_tags(job, path)
        out = {k: tags[k] for k, _l in FIELDS[kind] if tags.get(k)}
        if kind == "audio" and "track" not in out and tags.get("tracknumber"):
            out["track"] = tags["tracknumber"]
        return out
    if kind == "pdf":
        return await asyncio.to_thread(_pdf_read, path)
    if kind == "image":
        j = await _exif_json(job, path)
        out = {}
        for k, tag in EXIF_KEYS.items():
            for jk, v in j.items():
                if jk.split(":")[-1].lower() == tag.split(":")[-1].lower() and v not in ("", None):
                    out[k] = str(v)
                    break
        return out
    return {}


async def exif_all(job, path) -> list:
    j = await _exif_json(job, path)
    skip = {"SourceFile", "System:FileName", "System:Directory"}
    return [(k, str(v)[:100]) for k, v in j.items() if k not in skip and not k.startswith("System:")][:40]


def diff_lines(old: dict, new: dict, kind: str) -> list:
    labels = dict(FIELDS.get(kind, []))
    lines = []
    for k in sorted(set(old) | set(new), key=lambda x: list(labels).index(x) if x in labels else 99):
        if old.get(k) != new.get(k):
            lines.append(f"• {labels.get(k, k)}: <s>{esc(old.get(k, '—'))}</s> ← <b>{esc(new.get(k, '—'))}</b>")
    return lines


# ---------- تعديل ----------
async def edit(rc, src: Path, dst: Path, kind: str, changes: dict):
    if kind in ("audio", "video"):
        maps = ["-map", "0"] if kind == "audio" else ["-map", "0:v?", "-map", "0:a?", "-map", "0:s?"]
        md = []
        for k, v in changes.items():
            md += ["-metadata", f"{k}={v}"]
        extra = ["-id3v2_version", "3"] if src.suffix.lower() == ".mp3" else []
        await ff(rc, ["-i", src, *maps, "-c", "copy", *md, *extra, dst], rc.probe.get("duration"), "🏷️ بعدّل")
    elif kind == "pdf":
        await asyncio.to_thread(_pdf_write, src, dst, changes)
    elif kind == "image":
        shutil.copyfile(src, dst)
        args = ["exiftool", "-overwrite_original"] + [f"-{EXIF_KEYS[k]}={v}" for k, v in changes.items()] + [str(dst)]
        code, _o, err = await run_cmd(rc.job, *args, timeout=120)
        if code != 0:
            raise UserError("exiftool مقدرش يعدّل الملف ده.\n<code>" + esc((err or b'').decode('utf-8', 'replace')[-200:]) + "</code>")
    else:
        raise UserError("تعديل الحقول مش مدعوم للنوع ده — تقدر تحذف الـ metadata بس.")


async def strip(rc, src: Path, dst: Path, kind: str, keep_cover: bool = False):
    if kind in ("audio", "video"):
        bit = ["-fflags", "+bitexact", "-flags:v", "+bitexact", "-flags:a", "+bitexact"]
        base = ["-i", src, "-map_metadata", "-1", "-map_metadata:s:v", "-1", "-map_metadata:s:a", "-1",
                "-map_chapters", "-1", "-c", "copy", *bit]
        if kind == "audio":
            maps = ["-map", "0:a", *(["-map", "0:v?"] if keep_cover else [])]
            await ff(rc, [*base[:2], *maps, *base[2:], dst], rc.probe.get("duration"), "🧹 بمسح")
        else:
            try:
                await ff(rc, [*base[:2], "-map", "0:v?", "-map", "0:a?", "-map", "0:s?", *base[2:], dst],
                         rc.probe.get("duration"), "🧹 بمسح")
            except UserError:   # ترجمات بصيغة مش بتتنسخ في الحاوية دي
                await ff(rc, [*base[:2], "-map", "0:v?", "-map", "0:a?", *base[2:], dst], rc.probe.get("duration"), "🧹 بمسح")
    elif kind == "pdf":
        await asyncio.to_thread(_pdf_strip, src, dst)
    else:
        shutil.copyfile(src, dst)
        code, _o, err = await run_cmd(rc.job, "exiftool", "-all=", "-tagsfromfile", "@", "-Orientation",
                                      "-overwrite_original", str(dst), timeout=120)
        if code != 0:
            raise UserError("exiftool مبيدعمش الصيغة دي.\n<code>" + esc((err or b'').decode('utf-8', 'replace')[-200:]) + "</code>")


async def set_cover(rc, src: Path, img: Path, dst: Path):
    """غلاف جديد (mp3/m4a/flac): بنحوّل الصورة لـ JPEG الأول عشان تتوافق."""
    jpg = rc.jobdir / "cover.jpg"
    try:
        from PIL import Image
        with Image.open(img) as im:
            im.convert("RGB").save(jpg, "JPEG", quality=92)
    except Exception:
        raise UserError("مقدرتش أقرأ الصورة دي. ابعتها كـ JPG أو PNG.") from None
    extra = ["-id3v2_version", "3"] if src.suffix.lower() == ".mp3" else []
    await ff(rc, ["-i", src, "-i", jpg, "-map", "0:a", "-map", "1:v", "-map_metadata", "0", "-c", "copy",
                  "-disposition:v:0", "attached_pic", "-metadata:s:v", "title=Album cover",
                  "-metadata:s:v", "comment=Cover (front)", *extra, dst], rc.probe.get("duration"), "🖼 بحط الغلاف")
