"""الصوت (FFmpeg): صيغ، bitrate، قص، تقسيم، دمج، تنقية. كل التشغيل عبر core.ffrun (exec + progress + إلغاء)."""
from __future__ import annotations

import shutil
import sys
from pathlib import Path

from core.ffrun import ff
from core.queue import UserError, run_cmd
from core.utils import esc

# fmt: (codec, ext, lossy)
FORMATS = {
    "mp3": ("libmp3lame", ".mp3", True), "m4a": ("aac", ".m4a", True), "opus": ("libopus", ".opus", True),
    "ogg": ("libvorbis", ".ogg", True), "wav": ("pcm_s16le", ".wav", False), "flac": ("flac", ".flac", False),
}
LABELS = {"mp3": "MP3", "m4a": "M4A (AAC)", "opus": "OPUS", "ogg": "OGG", "wav": "WAV (بدون فقد)", "flac": "FLAC (بدون فقد)"}
BITRATES = [64, 96, 128, 160, 192, 256, 320]
EXT_FMT = {".mp3": "mp3", ".m4a": "m4a", ".aac": "m4a", ".opus": "opus", ".ogg": "ogg", ".oga": "ogg",
           ".wav": "wav", ".flac": "flac"}
SAMPLE_RATES = [48000, 44100, 32000, 22050, 16000]


def fmt_for_ext(ext: str, fallback: str = "mp3") -> str:
    return EXT_FMT.get((ext or "").lower(), fallback)


def src_kbps(probe: dict) -> int:
    return int((probe.get("audio_bitrate") or probe.get("bitrate") or 0) // 1000)


def allowed_bitrates(probe: dict, fmt: str):
    """مفيش فايدة من bitrate أعلى من الأصل — فمبنعرضوش."""
    src, cap = src_kbps(probe), (256 if fmt == "opus" else 320)
    opts = [b for b in BITRATES if b <= cap and (not src or b <= src + 8)]
    return (opts or [BITRATES[0]]), src


def pick_bitrate(probe: dict, fmt: str, wanted: int) -> int:
    opts, _ = allowed_bitrates(probe, fmt)
    ok = [b for b in opts if b <= wanted]
    return ok[-1] if ok else opts[0]


def enc_args(fmt: str, bitrate: int = 0, channels: int = 0, sr: int = 0) -> list:
    codec, _ext, lossy = FORMATS[fmt]
    a = ["-c:a", codec]
    if lossy and bitrate:
        a += ["-b:a", f"{bitrate}k"]
    if channels:
        a += ["-ac", str(channels)]
    if sr and fmt != "opus":
        a += ["-ar", str(sr)]
    return a


def cover_args(probe: dict, fmt: str) -> list:
    """بنحافظ على الغلاف لو الصيغة الناتجة بتدعمه."""
    if probe.get("has_cover") and fmt in ("mp3", "m4a", "flac"):
        return ["-map", "0:v:0?", "-c:v", "copy", "-disposition:v:0", "attached_pic"]
    return []


async def convert(rc, src: Path, dst: Path, fmt: str, bitrate=0, channels=0, sr=0, duration=None, label="🔁 بحوّل"):
    args = ["-i", src, "-map", "0:a:0", "-map_metadata", "0", *cover_args(rc.probe, fmt),
            *enc_args(fmt, bitrate, channels, sr), dst]
    await ff(rc, args, duration, label)


async def cut_copy(rc, src: Path, dst: Path, start: float, dur: float, label="✂️ بقص"):
    await ff(rc, ["-ss", f"{start:.3f}", "-i", src, "-t", f"{dur:.3f}", "-map", "0:a:0", "-map_metadata", "0",
                  "-c", "copy", dst], dur, label)


def compatible(probes: list) -> bool:
    keys = ("acodec", "sample_rate", "channels")
    first = tuple(probes[0].get(k) for k in keys)
    return all(tuple(p.get(k) for k in keys) == first and first[0] for p in probes)


def _list_line(p: Path) -> str:
    return "file '" + str(p).replace("'", "'\\''") + "'\n"


async def concat(rc, files: list, dst: Path, fmt: str, probes: list, label="🧩 بدمج"):
    total = sum((p.get("duration") or 0) for p in probes) or None
    if compatible(probes) and fmt_for_ext(files[0].suffix, "") == fmt:
        lst = rc.jobdir / "list.txt"
        lst.write_text("".join(_list_line(f) for f in files), encoding="utf-8")
        await ff(rc, ["-f", "concat", "-safe", "0", "-i", lst, "-map", "0:a:0", "-map_metadata", "0", "-c", "copy", dst],
                 total, label)
        return False
    sr = probes[0].get("sample_rate") or 44100
    layout = "mono" if probes[0].get("channels") == 1 else "stereo"
    ins, fl = [], []
    for n, f in enumerate(files):
        ins += ["-i", f]
        fl.append(f"[{n}:a:0]aformat=sample_fmts=fltp:sample_rates={sr}:channel_layouts={layout}[a{n}]")
    chain = ";".join(fl) + ";" + "".join(f"[a{n}]" for n in range(len(files))) + f"concat=n={len(files)}:v=0:a=1[out]"
    br = pick_bitrate(probes[0], fmt, src_kbps(probes[0]) or 192)
    await ff(rc, [*ins, "-filter_complex", chain, "-map", "[out]", *enc_args(fmt, br), dst], total, label)
    return True   # اتحوّلت لصيغة موحدة


DENOISE_FF = "highpass=f=80,afftdn=nf=-25,loudnorm=I=-16:TP=-1.5:LRA=11"


async def ensure_deepfilter(rc) -> str:
    exe = shutil.which("deepFilter") or (str(Path(sys.executable).parent / "deepFilter")
                                          if (Path(sys.executable).parent / "deepFilter").exists() else None)
    if exe:
        return exe
    await rc.say("⏳ بجهّز DeepFilterNet لأول مرة (ممكن ياخد كام دقيقة)…", True)
    code, _o, err = await run_cmd(rc.job, sys.executable, "-m", "pip", "install", "-q", "--break-system-packages",
                                  "deepfilternet", timeout=1200)
    p = Path(sys.executable).parent / "deepFilter"
    exe = shutil.which("deepFilter") or (str(p) if p.exists() else None)
    if code != 0 or not exe:
        rc.ctx.store.kv_set("dfn_failed", True)
        raise UserError("تثبيت DeepFilterNet فشل على الجلسة دي، فخيار الـ AI اتخفى. "
                        "جرّب «تنقية سريعة (FFmpeg)».\n<code>" + esc((err or b"").decode("utf-8", "replace")[-300:]) + "</code>")
    return exe


async def denoise_ai(rc, src: Path, dst: Path, fmt: str, bitrate: int, duration):
    exe = await ensure_deepfilter(rc)
    wav_in, outdir = rc.jobdir / "dn_in.wav", rc.jobdir / "dn_out"
    outdir.mkdir(exist_ok=True)
    await ff(rc, ["-i", src, "-map", "0:a:0", "-ar", "48000", "-ac", "1", "-c:a", "pcm_s16le", wav_in], duration,
             "🤖 تجهيز")
    await rc.say("🤖 <b>تنقية AI</b> شغّالة… (أبطأ، خصوصًا من غير GPU)", True)
    code, _o, err = await run_cmd(rc.job, exe, "-o", outdir, wav_in, timeout=None)
    res = next(iter(outdir.glob("*.wav")), None)
    if code != 0 or not res:
        raise UserError("DeepFilterNet فشل على الملف ده. جرّب «تنقية سريعة (FFmpeg)».\n<code>"
                        + esc((err or b"").decode("utf-8", "replace")[-300:]) + "</code>")
    await ff(rc, ["-i", res, "-map_metadata", "-1", *enc_args(fmt, bitrate), dst], duration, "🎚 ترميز")
