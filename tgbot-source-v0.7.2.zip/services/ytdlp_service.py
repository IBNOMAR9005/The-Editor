"""yt-dlp: معلومات الرابط، الصيغ المتاحة، التحميل مع progress، رسائل أخطاء مفهومة، التحديث.
كله exec بمعاملات list، والرابط بعد `--` عشان ميتفسّرش كخيار (منع command injection)."""
from __future__ import annotations

import asyncio
import json
import os
import re
import sys
import tempfile
from pathlib import Path

from core.queue import UserError
from core.utils import esc

URL_RE = re.compile(r"https?://[^\s<>\"']+", re.I)
MAX_PLAYLIST = 50
LIMIT = 2000 * 1024 ** 2

_ERRORS = [
    (r"sign in to confirm|not a bot|confirm you.?re not a bot|cookies", "🔐 الموقع طلب تسجيل دخول/تأكيد إنك مش روبوت (يوتيوب بيحظر IP بتاع Colab كتير). "
     "ضيف <code>YT_COOKIES</code> في Colab Secrets (محتوى cookies.txt) وأعد تشغيل الخلية 3."),
    (r"private video", "🔒 الفيديو ده خاص (private)."),
    (r"members.only|join this channel", "🔒 الفيديو ده للمشتركين فقط."),
    (r"age.restrict|confirm your age|inappropriate for some users", "🔞 الفيديو بقيود عمرية — محتاج cookies حساب مسجّل."),
    (r"not available in your country|geo.?restrict|blocked it in your country|not made this video available", "🌍 الفيديو محجوب في منطقة السيرفر."),
    (r"video unavailable|has been removed|no longer available|account.*terminated|does not exist", "🚫 الفيديو مش متاح (اتحذف أو اتخفى)."),
    (r"http error 429|too many requests|rate.?limit", "⏳ الموقع حاظر الطلبات مؤقتًا (429). استنى شوية وجرّب تاني."),
    (r"unsupported url", "❓ الرابط ده مش مدعوم من yt-dlp. جرّب 🔄 تحديث yt-dlp أو رابط تاني."),
    (r"live event will begin|is live|premieres in", "📡 ده بث مباشر/لسه مبدأش — مينفعش يتحمّل دلوقتي."),
    (r"larger than max-filesize|file is larger", "📦 الملف أكبر من 2GB — اختار جودة أقل."),
    (r"unable to download webpage|name or service not known|connection|timed out", "🌐 مشكلة اتصال بالموقع. جرّب تاني بعد شوية."),
    (r"ffmpeg|ffprobe", "🎞 مشكلة في ffmpeg أثناء الدمج/التحويل."),
]


def map_error(text: str) -> str:
    low = (text or "").lower()
    for pat, msg in _ERRORS:
        if re.search(pat, low):
            return msg
    last = [l for l in (text or "").strip().splitlines() if l.strip()][-1:] or ["؟"]
    return "❌ yt-dlp مقدرش يكمّل.\n<code>" + esc(last[0][:300]) + "</code>\nجرّب 🔄 تحديث yt-dlp."


_js_cache: dict = {}


async def _exec(args, timeout=120):
    proc = await asyncio.create_subprocess_exec(sys.executable, "-m", "yt_dlp", *map(str, args),
                                                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout)
    except asyncio.TimeoutError:
        proc.kill()
        raise UserError("⏳ الموقع اتأخر في الرد. جرّب تاني.") from None
    return proc.returncode, out.decode("utf-8", "replace"), err.decode("utf-8", "replace")


async def js_args() -> list:
    """يوتيوب بقى محتاج JS runtime (node موجود على Colab). بنضيفه بس لو yt-dlp ده بيدعمه."""
    if "v" not in _js_cache:
        _c, out, _e = await _exec(["--help"], 30)
        _js_cache["v"] = ["--js-runtimes", "node"] if "--js-runtimes" in out else []
    return _js_cache["v"]


def write_cookies(text: str, folder: Path) -> Path | None:
    if not text:
        return None
    folder.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix="ck_", suffix=".txt", dir=str(folder))
    with os.fdopen(fd, "w") as f:
        f.write(text if text.endswith("\n") else text + "\n")
    os.chmod(name, 0o600)
    return Path(name)


async def common(cookies: Path | None) -> list:
    a = ["--no-warnings", "--socket-timeout", "30", "--retries", "5", *(await js_args())]
    if cookies:
        a += ["--cookies", cookies]
    return a


def single_url(url: str) -> bool:
    """رابط فيديو جواه list= يتعامل كفيديو واحد (إلا لو صفحة playlist صريحة)."""
    return "list=" in url and ("v=" in url or "youtu.be/" in url) and "/playlist" not in url


def _size(f: dict, dur):
    s = f.get("filesize") or f.get("filesize_approx")
    if not s and f.get("tbr") and dur:
        s = int(f["tbr"] * 1000 / 8 * dur)
    return s or 0


def distill(info: dict, url: str) -> dict:
    dur = info.get("duration")
    out = {"url": url, "title": info.get("title") or "video", "uploader": info.get("uploader") or info.get("channel") or "",
           "duration": dur, "type": "video", "heights": [], "audio_kbps": 0}
    if info.get("_type") == "playlist" or info.get("entries") is not None:
        ents = []
        for e in info.get("entries") or []:
            if not e:
                continue
            u = e.get("url") or e.get("webpage_url")
            if u and u.startswith("http"):
                ents.append({"url": u, "title": e.get("title") or "item"})
        out.update(type="playlist", entries=ents[:MAX_PLAYLIST * 4], count=len(ents))
        return out
    fm = info.get("formats") or []
    best_a = max((_size(f, dur) for f in fm if f.get("vcodec") == "none" and f.get("acodec") not in (None, "none")), default=0)
    by_h: dict = {}
    for f in fm:
        h = f.get("height")
        if h and f.get("vcodec") not in (None, "none"):
            by_h[h] = max(by_h.get(h, 0), _size(f, dur) + (0 if f.get("acodec") not in (None, "none") else best_a))
    out["heights"] = sorted(by_h.items(), reverse=True)
    return out


async def fetch_info(url: str, cookies_text: str, work: Path) -> dict:
    ck = write_cookies(cookies_text, work / "tmp")
    try:
        args = [*await common(ck), "-J", "--flat-playlist"]
        if single_url(url):
            args.append("--no-playlist")
        code, out, err = await _exec([*args, "--", url], 120)
    finally:
        if ck:
            ck.unlink(missing_ok=True)
    if code != 0:
        raise UserError(map_error(err))
    try:
        return distill(json.loads(out), url)
    except Exception:
        raise UserError("❌ مقدرتش أفهم رد الموقع. جرّب 🔄 تحديث yt-dlp.") from None


def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


async def download(rc, url: str, stem: str, mode: str, height=None, afmt="mp3", abr=192, cookies: Path | None = None,
                   label="⬇️ بحمّل") -> Path:
    """بينزّل في rc.jobdir ويرجّع مسار الملف الناتج."""
    out = f"{rc.jobdir}/{stem}.%(ext)s"
    args = [*await common(cookies), "--newline", "--no-colors", "--no-playlist", "--max-filesize", "2000M",
            "--progress-template",
            "download:PRG:%(progress.downloaded_bytes)s|%(progress.total_bytes)s|%(progress.total_bytes_estimate)s|%(progress.speed)s|%(progress.eta)s",
            "-o", out]
    if mode == "audio":
        args += ["-f", "ba/b", "-x", "--audio-format", afmt, "--audio-quality", f"{abr}K"]
    else:
        h = f"[height<={height}]" if height else ""
        args += ["-f", f"bv*{h}+ba/b{h}/bv*+ba/b", "--merge-output-format", "mp4"]
    proc = await asyncio.create_subprocess_exec(sys.executable, "-m", "yt_dlp", *map(str, args), "--", url,
                                                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    rc.job.procs.add(proc)
    errs: list = []

    async def drain():
        async for line in proc.stderr:
            errs.append(line.decode("utf-8", "replace").rstrip())

    t = asyncio.create_task(drain())
    try:
        async for raw in proc.stdout:
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("PRG:"):
                continue
            d, tot, est, spd, eta = (line[4:].split("|") + [""] * 5)[:5]
            total = _num(tot) or _num(est)
            if total:
                from core.progress import bar
                from core.utils import human_size
                sp = f" • {human_size(_num(spd))}/s" if _num(spd) else ""
                et = f" • باقي ~{int(_num(eta))}ث" if _num(eta) else ""
                await rc.rep.update(f"{label} <b>{rc.tool.title}</b>\n{bar(_num(d) * 100 / total)}{sp}{et}")
        code = await proc.wait()
        await asyncio.wait_for(t, 5)
    finally:
        t.cancel()
        rc.job.procs.discard(proc)
        if proc.returncode is None:
            proc.kill()
    if code != 0:
        raise UserError(map_error("\n".join(errs)))
    found = [p for p in rc.jobdir.glob(f"{stem}.*") if p.suffix not in (".part", ".ytdl", ".temp")]
    if not found:
        raise UserError("التحميل خلص لكن مالقيتش الملف الناتج (ممكن يكون عدّى حد الـ 2GB).")
    return max(found, key=lambda p: p.stat().st_mtime)


async def update_ytdlp() -> tuple:
    """(نسخة قبل, نسخة بعد, نجح؟)"""
    _c, before, _e = await _exec(["--version"], 30)
    for target in ("yt-dlp[default]", "yt-dlp"):
        proc = await asyncio.create_subprocess_exec(sys.executable, "-m", "pip", "install", "-q", "-U",
                                                    "--break-system-packages", target,
                                                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
        try:
            await asyncio.wait_for(proc.communicate(), 300)
        except asyncio.TimeoutError:
            proc.kill()
            continue
        if proc.returncode == 0:
            break
    _js_cache.clear()
    _c, after, _e = await _exec(["--version"], 30)
    return before.strip(), after.strip(), bool(after.strip())
