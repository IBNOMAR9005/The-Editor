"""PDF: ضغط (Ghostscript)، صفحات/تقسيم/دمج/تدوير/حذف/حماية (pikepdf)، صور (PyMuPDF). كله محلي، من غير خدمات خارجية.
الدوال الثقيلة بتشتغل في thread وبتفحص الإلغاء (job.cancelled) بين الصفحات."""
from __future__ import annotations

import asyncio
import zipfile
from pathlib import Path

from core.queue import UserError, run_cmd
from core.utils import esc
from services.ocr_service import fitz_mod

GS_PRESETS = {"screen": "أصغر حجم (72dpi)", "ebook": "متوازن (150dpi)", "printer": "جودة عالية (300dpi)"}


def _cancel(rc):
    rc.check_cancel()


def pdf_open(path, password: str = ""):
    import pikepdf
    try:
        return pikepdf.open(str(path), password=password)
    except pikepdf.PasswordError:
        if password:
            raise UserError("كلمة السر غلط. جرّب تاني.") from None
        raise UserError("الـ PDF محمي بكلمة سر. فك الحماية الأول من 🛠 أدوات PDF.") from None
    except Exception as e:
        raise UserError(f"مقدرتش أفتح الـ PDF ({type(e).__name__}) — الملف ممكن يكون تالف.") from None


# ---------- ضغط ----------
async def compress(rc, src: Path, dst: Path, preset: str):
    cmd = ["gs", "-sDEVICE=pdfwrite", "-dCompatibilityLevel=1.5", f"-dPDFSETTINGS=/{preset}", "-dNOPAUSE", "-dQUIET",
           "-dBATCH", "-dDetectDuplicateImages=true", "-dCompressFonts=true", f"-sOutputFile={dst}", str(src)]
    await rc.say(f"🗜 <b>ضغط PDF</b> ({GS_PRESETS[preset]})…\n<i>مفيش progress حقيقي من Ghostscript.</i>", True)
    try:
        code, _o, err = await run_cmd(rc.job, *cmd)
    except FileNotFoundError:
        raise UserError("Ghostscript مش متثبّت — شغّل bootstrap (الخلية 5).") from None
    if code != 0 or not dst.exists():
        raise UserError("Ghostscript فشل على الملف ده.\n<code>" + esc((err or b"").decode("utf-8", "replace")[-300:]) + "</code>")


# ---------- صفحات ----------
def _extract_pages(src, dst, pages: list):
    import pikepdf
    with pdf_open(src) as s:
        d = pikepdf.new()
        d.pages.extend([s.pages[i - 1] for i in pages])
        d.save(str(dst))


async def extract_pages(rc, src, dst, pages):
    await asyncio.to_thread(_extract_pages, src, dst, pages)


def _split(rc, src, outs_fn, n):
    import pikepdf
    outs = []
    with pdf_open(src) as s:
        total = len(s.pages)
        for part, a in enumerate(range(0, total, n), 1):
            _cancel(rc)
            d = pikepdf.new()
            d.pages.extend(list(s.pages)[a:a + n])
            p = outs_fn(part)
            d.save(str(p))
            outs.append(p)
    return outs


async def split_every(rc, src, n: int):
    return await asyncio.to_thread(_split, rc, src, lambda part: rc.out(".pdf", part=part), n)


def _merge_keep(rc, files, dst):
    import pikepdf
    srcs, d = [], pikepdf.new()
    try:
        for f in files:
            _cancel(rc)
            s = pdf_open(f)
            srcs.append(s)
            d.pages.extend(list(s.pages))
        d.save(str(dst))
    finally:
        for s in srcs:
            s.close()


async def merge(rc, files, dst):
    await asyncio.to_thread(_merge_keep, rc, files, dst)


def _edit(src, dst, op: str, pages: list, angle: int = 0, password: str = "", unlock_pw: str = ""):
    import pikepdf
    with pdf_open(src, unlock_pw) as pdf:
        if op == "rotate":
            for i in pages:
                pdf.pages[i - 1].rotate(angle, relative=True)
        elif op == "delete":
            for i in sorted(set(pages), reverse=True):
                del pdf.pages[i - 1]
        if op == "protect":
            pdf.save(str(dst), encryption=pikepdf.Encryption(owner=password, user=password, R=6))
        else:
            pdf.save(str(dst))


async def edit(rc, src, dst, op, pages=(), angle=0, password="", unlock_pw=""):
    await asyncio.to_thread(_edit, src, dst, op, list(pages), angle, password, unlock_pw)


# ---------- علامة مائية ----------
def _watermark(rc, src, dst, text: str):
    m = fitz_mod()
    css = "* {font-family: 'Noto Naskh Arabic','Noto Sans Arabic','DejaVu Sans',sans-serif; color:#b4b4b4; text-align:center; font-size: 46px; font-weight: bold;}"
    html = f"<p>{esc(text)}</p>"
    with m.open(str(src)) as doc:
        if doc.needs_pass:
            raise UserError("الـ PDF محمي بكلمة سر — فك الحماية الأول.")
        for page in doc:
            _cancel(rc)
            r = page.rect
            box = m.Rect(r.width * 0.1, r.height * 0.42, r.width * 0.9, r.height * 0.58)
            page.insert_htmlbox(box, html, css=css, overlay=True)
        doc.save(str(dst), garbage=3, deflate=True)


async def watermark(rc, src, dst, text):
    try:
        await asyncio.to_thread(_watermark, rc, src, dst, text)
    except AttributeError:
        raise UserError("إصدار PyMuPDF عندك قديم ومبيدعمش العلامة المائية (insert_htmlbox). حدّثه: pip install -U pymupdf") from None


# ---------- صور ----------
MAX_PAGES_IMG = 300


def _to_images(rc, src, outdir: Path, dpi: int, fmt: str):
    m = fitz_mod()
    outs = []
    with m.open(str(src)) as doc:
        if doc.needs_pass:
            raise UserError("الـ PDF محمي بكلمة سر — فك الحماية الأول.")
        if len(doc) > MAX_PAGES_IMG:
            raise UserError(f"الملف فيه {len(doc)} صفحة — الحد {MAX_PAGES_IMG} صفحة للتحويل لصور. "
                            "استخرج الصفحات اللي عايزها الأول من 📑 استخراج صفحات.")
        for i, page in enumerate(doc, 1):
            _cancel(rc)
            pix = page.get_pixmap(dpi=dpi, alpha=False)
            p = outdir / f"page_{i:03d}.{fmt}"
            pix.save(str(p), **({"jpg_quality": 90} if fmt == "jpg" else {}))
            outs.append(p)
    return outs


def _zip(files, dst: Path):
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_STORED) as z:
        for f in files:
            z.write(f, f.name)
    return dst


async def pdf_to_images(rc, src, dpi, fmt):
    d = rc.jobdir / "imgs"
    d.mkdir(exist_ok=True)
    files = await asyncio.to_thread(_to_images, rc, src, d, dpi, fmt)
    if len(files) == 1:
        one = rc.out("." + fmt)
        files[0].replace(one)
        return [one]
    return [await asyncio.to_thread(_zip, files, rc.out(".zip", suffix=" (images)"))]


def _extract_images(rc, src, outdir: Path, min_px: int):
    m = fitz_mod()
    seen, outs = set(), []
    with m.open(str(src)) as doc:
        if doc.needs_pass:
            raise UserError("الـ PDF محمي بكلمة سر — فك الحماية الأول.")
        for page in doc:
            _cancel(rc)
            for img in page.get_images(full=True):
                xref = img[0]
                if xref in seen:
                    continue
                seen.add(xref)
                try:
                    info = doc.extract_image(xref)
                except Exception:
                    continue
                if not info or min(info.get("width", 0), info.get("height", 0)) < min_px:
                    continue
                p = outdir / f"img_{len(outs) + 1:03d}_p{page.number + 1}.{info.get('ext', 'png')}"
                p.write_bytes(info["image"])
                outs.append(p)
    return outs


async def extract_images(rc, src, min_px: int):
    d = rc.jobdir / "imgs"
    d.mkdir(exist_ok=True)
    files = await asyncio.to_thread(_extract_images, rc, src, d, min_px)
    if not files:
        raise UserError("مفيش صور مستخرجة (الملف مفيهوش صور مدمجة، أو كلها أصغر من الحد اللي اخترته).")
    return [await asyncio.to_thread(_zip, files, rc.out(".zip", suffix=" (images)"))]
