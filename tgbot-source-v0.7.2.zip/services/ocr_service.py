"""OCR (ocrmypdf + tesseract) وكشف الـ PDF الممسوح ضوئيًا."""
from __future__ import annotations

import subprocess
import sys

from core.queue import UserError, run_cmd
from core.utils import esc


def fitz_mod():
    try:
        import pymupdf as m
    except ImportError:
        import fitz as m  # type: ignore
    return m


def is_scanned(path) -> bool | None:
    """True = صور من غير نص (محتاج OCR) • False = فيه نص • None = مش قادر أحدد (PyMuPDF مش موجود/ملف غريب)."""
    try:
        m = fitz_mod()
    except ImportError:
        return None
    with m.open(str(path)) as doc:
        if doc.needs_pass or not len(doc):
            return None
        n = min(len(doc), 5)
        text = sum(len(doc[i].get_text().strip()) for i in range(n))
        imgs = sum(len(doc[i].get_images()) for i in range(n))
    if text >= 20 * n:
        return False
    return True if imgs else None


def tesseract_langs() -> set:
    try:
        r = subprocess.run(["tesseract", "--list-langs"], capture_output=True, text=True, timeout=20)
        return set(r.stdout.split()[1:])
    except Exception:
        return set()


async def ensure_ocrmypdf(rc):
    try:
        import ocrmypdf  # noqa: F401
        return
    except ImportError:
        pass
    await rc.say("⏳ بجهّز أداة الـ OCR لأول مرة…", True)
    code, _o, err = await run_cmd(rc.job, sys.executable, "-m", "pip", "install", "-q", "--break-system-packages",
                                  "ocrmypdf", timeout=600)
    try:
        import importlib
        importlib.invalidate_caches()
        import ocrmypdf  # noqa: F401
    except ImportError:
        raise UserError("تثبيت ocrmypdf فشل.\n<code>" + esc((err or b"").decode("utf-8", "replace")[-300:]) + "</code>") from None


async def ocr_pdf(rc, src, dst, lang: str, skip_text: bool):
    have = tesseract_langs()
    need = set(lang.split("+"))
    if need - have:
        raise UserError(f"لغة الـ OCR ({', '.join(sorted(need - have))}) مش متثبّتة. شغّل bootstrap تاني "
                        "(الخلية 5) عشان يثبّت tesseract-ocr-ara.")
    await ensure_ocrmypdf(rc)
    await rc.say("🔍 <b>OCR</b> شغّال… الملفات الكبيرة والعربي بياخدوا وقت (مفيش progress حقيقي).", True)
    cmd = [sys.executable, "-m", "ocrmypdf", "-l", lang, "--skip-text" if skip_text else "--force-ocr",
           "--output-type", "pdf", "--optimize", "1", "--jobs", "2", src, dst]
    code, _o, err = await run_cmd(rc.job, *cmd)
    msg = (err or b"").decode("utf-8", "replace")
    if code == 0:
        return
    if "encrypted" in msg.lower() or code == 8:
        raise UserError("الـ PDF محمي بكلمة سر — فك الحماية الأول من 🛠 أدوات PDF.")
    if code == 6:
        raise UserError("الملف فيه نص بالفعل. اختار «OCR لكل الصفحات» لو عايز تعيد.")
    raise UserError("الـ OCR فشل على الملف ده.\n<code>" + esc(msg[-400:]) + "</code>")
