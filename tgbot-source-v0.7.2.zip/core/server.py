"""إدارة Local Telegram Bot API Server: الـ binary (3 طبقات)، logOut مرة واحدة، تشغيل/فحص/إيقاف.
CLI:  python -m core.server  [binary|logout|start|check|stop]"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import Config  # noqa: E402
from core import assets  # noqa: E402
from core.utils import redact_text  # noqa: E402


def platform_tag() -> str:
    """نسخة Ubuntu الحالية (22.04 / 24.04) — الـ binary بيتبني لكل نسخة."""
    try:
        for line in Path("/etc/os-release").read_text().splitlines():
            if line.startswith("VERSION_ID="):
                return line.split("=", 1)[1].strip().strip('"')
    except Exception:
        pass
    return "unknown"


def asset_name() -> str:
    return f"telegram-bot-api-ubuntu-{platform_tag()}"


def binary_version(binary: Path) -> str | None:
    try:
        r = subprocess.run([str(binary), "--version"], capture_output=True, text=True, timeout=20)
        out = (r.stdout + r.stderr).strip().splitlines()
        return out[0] if r.returncode == 0 and out else None
    except Exception:
        return None


def _log(msg):
    print(msg, flush=True)


# ------------------------------------------------------------------ الـ binary (3 طبقات)
def ensure_binary(cfg: Config, repo: str, tag: str = "latest", gh_token: str | None = None) -> dict:
    cfg.ensure_dirs()
    target, name = cfg.binary, asset_name()

    # 0) موجود وشغّال؟
    if target.exists() and binary_version(target):
        return {"layer": "موجود", "version": binary_version(target)}

    errors = []

    # 1) GitHub Release
    try:
        _log(f"⬇️ بنزّل {name} من GitHub Release…")
        assets.fetch_verified(repo, tag, name, target, gh_token)
        target.chmod(0o755)
        v = binary_version(target)
        if v:
            _backup_to_drive(cfg, target)
            return {"layer": "GitHub Release", "version": v}
        errors.append("الـ binary اتنزّل بس مبيشتغلش (--version فشل)")
    except Exception as e:
        errors.append(f"Release: {type(e).__name__}: {redact_text(e)[:120]}")

    # 2) نسخة Drive
    drive_bin, drive_sha = cfg.drive_bin / name, cfg.drive_bin / (name + ".sha256")
    if drive_bin.exists():
        try:
            _log("📦 بجرّب النسخة الاحتياطية من Drive…")
            if drive_sha.exists() and assets.parse_sha_file(drive_sha.read_text()) != assets.sha256_file(drive_bin):
                raise ValueError("checksum النسخة الاحتياطية مش مطابق")
            shutil.copyfile(drive_bin, target)
            target.chmod(0o755)
            v = binary_version(target)
            if v:
                return {"layer": "نسخة Drive", "version": v}
            errors.append("نسخة Drive مبتشتغلش على النسخة دي من Ubuntu")
        except Exception as e:
            errors.append(f"Drive: {type(e).__name__}: {str(e)[:100]}")

    # 3) بناء من المصدر
    script = Path(__file__).resolve().parent.parent / "scripts" / "build_binary.sh"
    if script.exists():
        _log("🛠 آخر حل: بناء من المصدر (10-25 دقيقة، هيتحفظ على Drive للمرة الجاية)…")
        # بنقرا المخرجات ونطبعها (Colab مبيعرضش ناتج subprocess اللي بيكتب مباشرة)
        pr = subprocess.Popen(["bash", str(script), str(cfg.bin_dir)], stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, text=True, bufsize=1)
        for line in pr.stdout:
            print(line.rstrip(), flush=True)
        rc = pr.wait()
        built = cfg.bin_dir / "telegram-bot-api"
        if rc == 0 and built.exists() and binary_version(built):
            sha = assets.sha256_file(built)
            Path(str(built) + ".sha256").write_text(f"{sha}  {name}\n")
            _backup_to_drive(cfg, built)
            return {"layer": "بناء من المصدر", "version": binary_version(built)}
        errors.append("البناء من المصدر فشل")
    raise RuntimeError("مقدرتش أجهّز الـ binary:\n - " + "\n - ".join(errors))


def _backup_to_drive(cfg: Config, binary: Path):
    try:
        if cfg.home.resolve() == cfg.work.resolve():
            return
        cfg.drive_bin.mkdir(parents=True, exist_ok=True)
        name = asset_name()
        shutil.copyfile(binary, cfg.drive_bin / name)
        (cfg.drive_bin / (name + ".sha256")).write_text(f"{assets.sha256_file(binary)}  {name}\n")
    except Exception as e:
        _log(f"⚠️ مقدرتش أحفظ نسخة احتياطية على Drive: {type(e).__name__}")


# ------------------------------------------------------------------ logOut (مرة واحدة)
def _token_fingerprint(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()[:16]


def logout_done(cfg: Config) -> bool:
    f = cfg.flags_dir / "logout.json"
    try:
        return json.loads(f.read_text()).get("fp") == _token_fingerprint(cfg.bot_token)
    except Exception:
        return False


def cloud_logout(cfg: Config) -> tuple:
    """يخرّج البوت من سيرفر تليجرام الرسمي (لازم قبل أول استخدام محلي). بيشتغل مرة واحدة لكل توكن.
    ملاحظة (من التوثيق الرسمي): بعد النجاح تقدر تشغّل السيرفر المحلي فورًا؛ الـ10 دقايق
    خاصة بالرجوع للسيرفر الرسمي بس. بيرجع (status, detail)."""
    if logout_done(cfg):
        return "skipped", "اتعمل قبل كده لنفس البوت"
    url = f"https://api.telegram.org/bot{cfg.bot_token}/logOut"
    status, detail = "error", ""
    try:
        with urllib.request.urlopen(urllib.request.Request(url, method="POST"), timeout=30) as r:
            data = json.load(r)
        status, detail = ("ok", "تم الخروج من السيرفر الرسمي") if data.get("ok") else ("error", str(data)[:150])
    except urllib.error.HTTPError as e:
        # 401/404 بعد logOut سابق = البوت أصلًا مش على السيرفر الرسمي. 429 = لسه ماسك logout حديث.
        if e.code in (401, 404, 429):
            status, detail = "already", f"البوت مش متسجّل على السيرفر الرسمي (HTTP {e.code})"
        else:
            detail = f"HTTP {e.code}"
    except Exception as e:
        detail = f"{type(e).__name__}"
    if status in ("ok", "already"):
        cfg.flags_dir.mkdir(parents=True, exist_ok=True)
        (cfg.flags_dir / "logout.json").write_text(json.dumps({"fp": _token_fingerprint(cfg.bot_token), "ts": time.time()}))
    return status, detail


# ------------------------------------------------------------------ تشغيل/فحص
def is_alive(cfg: Config, timeout: float = 8) -> bool:
    try:
        with urllib.request.urlopen(f"{cfg.server_url}/bot{cfg.bot_token}/getMe", timeout=timeout) as r:
            return bool(json.load(r).get("ok"))
    except urllib.error.HTTPError as e:
        return False
    except Exception:
        return False


def _port_open(cfg: Config) -> bool:
    import socket
    with socket.socket() as s:
        s.settimeout(1)
        return s.connect_ex(("127.0.0.1", cfg.port)) == 0


def _pidfile(cfg: Config) -> Path:
    return cfg.work / "server.pid"


def start(cfg: Config) -> subprocess.Popen | None:
    cfg.ensure_dirs()
    if _port_open(cfg):
        return None  # شغّال بالفعل
    env = dict(os.environ)
    env["TELEGRAM_API_ID"], env["TELEGRAM_API_HASH"] = str(cfg.api_id), cfg.api_hash  # مبيظهروش في ps
    logf = open(cfg.logs_dir / "server.log", "ab")
    proc = subprocess.Popen(
        [str(cfg.binary), "--local", f"--http-port={cfg.port}", "--http-ip-address=127.0.0.1",
         f"--dir={cfg.server_dir}", f"--temp-dir={cfg.server_tmp}", "--verbosity=1"],
        env=env, stdout=logf, stderr=logf, start_new_session=True)
    _pidfile(cfg).write_text(str(proc.pid))
    return proc


def wait_ready(cfg: Config, timeout: float = 90) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        if is_alive(cfg, timeout=5):
            return True
        time.sleep(2)
    return False


def ensure_running(cfg: Config, timeout: float = 90) -> bool:
    if is_alive(cfg, 5):
        return True
    start(cfg)
    return wait_ready(cfg, timeout)


def stop(cfg: Config):
    try:
        pid = int(_pidfile(cfg).read_text())
        os.killpg(os.getpgid(pid), signal.SIGTERM)
    except Exception:
        pass


def server_log_tail(cfg: Config, n: int = 15) -> str:
    try:
        lines = (cfg.logs_dir / "server.log").read_text(errors="replace").splitlines()[-n:]
        return redact_text("\n".join(lines), cfg.secret_values())
    except Exception:
        return ""


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "check"
    c = Config.from_env()
    if cmd == "logout":
        print(*cloud_logout(c))
    elif cmd == "start":
        ok = ensure_running(c)
        print("✅ السيرفر المحلي شغّال" if ok else "❌ السيرفر مارجعش getMe\n" + server_log_tail(c))
        sys.exit(0 if ok else 1)
    elif cmd == "stop":
        stop(c)
    else:
        print("alive" if is_alive(c) else "down")
