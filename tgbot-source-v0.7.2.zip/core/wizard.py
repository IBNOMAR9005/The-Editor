"""إطار الأدوات (wizard): كل وظيفة = Tool فيه Steps (أزرار/نص/ملفات) + run. المحرك في handlers/tools.py.
دي الحتة الوحيدة اللي بتعرّف شكل الحوار، فكل وظيفة جديدة = تعريف قصير مش handler جديد."""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable

from core.progress import bar
from core.utils import human_elapsed, sanitize_filename, split_ext

TOOLS: dict[str, "Tool"] = {}


@dataclass
class Step:
    key: str
    title: Any                      # str أو callable(sess, params, ctx)->str
    kind: str = "choice"            # choice | text | files | name
    options: Any = None             # [(label, value[, style])] أو callable(sess, params, ctx)
    default: Any = None             # قيمة أو callable(sess, params, ctx)؛ None = مفيش افتراضي
    when: Callable | None = None    # (params, sess) -> bool
    parse: Callable | None = None   # text -> value  (بيرمي ValueError برسالة عربي)
    accept: tuple = ()              # files: أنواع الملفات المقبولة
    min_files: int = 0              # files: أقل عدد ملفات إضافية
    cols: int = 2
    hint: str = ""                  # سطر توضيحي تحت العنوان


@dataclass
class Tool:
    key: str
    title: str
    steps: list
    run: Callable[["RunCtx"], Awaitable[list]]
    suffix: str = ""                # لاحقة الاسم الافتراضي للناتج
    needs_name: bool = True
    precheck: Callable | None = None   # (sess, ctx) -> رسالة خطأ أو None
    needs_file: bool = True


def register(tool: Tool) -> Tool:
    TOOLS[tool.key] = tool
    return tool


def val(x, *args):
    return x(*args) if callable(x) else x


# ---------- مدخلات الوقت والصفحات ----------
def parse_time(text: str) -> float:
    t = text.strip().replace("،", ":").replace(",", ".")
    if not re.fullmatch(r"\d+(?::\d{1,2}){0,2}(?:\.\d+)?", t):
        raise ValueError("الصيغة غلط. اكتب مثلًا <code>1:30</code> أو <code>00:01:30</code> أو <code>90</code> (ثواني).")
    parts = [float(p) for p in t.split(":")]
    sec = 0.0
    for p in parts:
        sec = sec * 60 + p
    return sec


def parse_ranges(text: str, n: int, contiguous: bool = False) -> list:
    """بيحوّل '1-3,7,10-12' لقايمة أرقام صفحات (من 1). contiguous=True يقبل مدى واحد بس (5-12 أو 5)."""
    t = text.strip().replace("،", ",").replace(" ", "").replace("–", "-").replace("—", "-")
    t = t.translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789"))
    if not t:
        raise ValueError("اكتب أرقام الصفحات.")
    chunks = t.split(",")
    if contiguous and len(chunks) > 1:
        raise ValueError("الوضع المتصل بيقبل مدى واحد بس (مثلًا <code>5-12</code>). بدّل للوضع المخصص لو عايز أكتر.")
    pages = []
    for c in chunks:
        m = re.fullmatch(r"(\d+)(?:-(\d+))?", c)
        if not m:
            raise ValueError("الصيغة غلط. اكتب مثلًا <code>5-12</code> أو <code>1-3,7,10-12</code>.")
        a = int(m[1]); b = int(m[2]) if m[2] else a
        if a < 1 or b < 1 or a > n or b > n:
            raise ValueError(f"في رقم خارج النطاق — الملف فيه <b>{n}</b> صفحة بس.")
        if a > b:
            raise ValueError(f"المدى <code>{c}</code> معكوس (البداية أكبر من النهاية).")
        pages += list(range(a, b + 1))
    return pages


def pages_label(pages: list) -> str:
    if not pages:
        return ""
    runs, a, b = [], pages[0], pages[0]
    for p in pages[1:]:
        if p == b + 1:
            b = p
        else:
            runs.append((a, b)); a = b = p
    runs.append((a, b))
    return ",".join(f"{x}" if x == y else f"{x}-{y}" for x, y in runs)[:40]


@dataclass
class RunCtx:
    bot: Any
    ctx: Any
    job: Any
    tool: Tool
    sess: dict
    extras: list
    params: dict
    jobdir: Path
    rep: Any
    chat_id: int
    notes: list = field(default_factory=list)
    sent: int = 0
    outs: list = field(default_factory=list)
    t0: float = field(default_factory=time.monotonic)
    send_hook: Any = None

    @property
    def src(self) -> Path:
        return Path(self.sess["local"])

    @property
    def probe(self) -> dict:
        return self.sess.get("probe", {})

    @property
    def uid(self) -> int:
        return self.sess["_uid"]

    def setting(self, key):
        return self.ctx.store.get_setting(self.uid, key)

    def out(self, ext: str, part: int | None = None, suffix: str | None = None) -> Path:
        """مسار ملف ناتج: الاسم اللي المستخدم كتبه أو الاسم الافتراضي (+ (partN) لو أجزاء)."""
        sfx = self.tool.suffix if suffix is None else suffix
        typed = self.params.get("name")
        if typed:
            stem = typed[: -len(ext)] if ext and typed.lower().endswith(ext.lower()) else typed
        else:
            stem = split_ext(self.sess["name"])[0] + sfx
        if part is not None:
            stem += f" (part{part})"
        return self.jobdir / sanitize_filename(stem + ext, fallback="output" + ext)

    def pct_cb(self, label: str):
        async def cb(pct):
            await self.rep.update(f"{label} <b>{self.tool.title}</b>\n{bar(pct)}\n"
                                  f"⏱ {human_elapsed(time.monotonic() - self.t0)}")
        return cb

    async def say(self, text: str, force: bool = False):
        await self.rep.update(text, force=force)

    async def send(self, path: Path):
        await self.send_hook(self, path)
        self.sent += 1

    def check_cancel(self):
        if self.job.cancelled:
            import asyncio
            raise asyncio.CancelledError()
