"""تشغيل ffmpeg مع progress حقيقي (-progress pipe:1). exec بمعاملات list (مفيش shell)، والـ process
بيتسجّل في المهمة عشان الإلغاء يقتله فعلًا."""
from __future__ import annotations

import asyncio
import re
from collections import deque

from core.queue import UserError
from core.utils import esc


class FFmpegError(Exception):
    def __init__(self, tail: str):
        super().__init__(tail)
        self.tail = tail


_TIME = re.compile(r"out_time=(\d+):(\d+):(\d+(?:\.\d+)?)")


async def run_ffmpeg(job, args, duration: float | None = None, on_pct=None, binary: str = "ffmpeg"):
    cmd = [binary, "-hide_banner", "-nostdin", "-y", "-loglevel", "error", "-progress", "pipe:1", "-nostats",
           *map(str, args)]
    proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    job.procs.add(proc)
    tail: deque = deque(maxlen=12)

    async def drain():
        async for line in proc.stderr:
            tail.append(line.decode("utf-8", "replace").rstrip())

    t = asyncio.create_task(drain())
    try:
        async for raw in proc.stdout:
            line = raw.decode("utf-8", "replace").strip()
            sec = None
            if line.startswith(("out_time_us=", "out_time_ms=")):
                try:
                    sec = int(line.split("=", 1)[1]) / 1_000_000
                except ValueError:
                    pass
            elif line.startswith("out_time="):
                m = _TIME.match(line)
                if m:
                    sec = int(m[1]) * 3600 + int(m[2]) * 60 + float(m[3])
            if sec is not None and duration and on_pct:
                await on_pct(max(0.0, min(99.0, sec * 100 / duration)))
        rc = await proc.wait()
        await asyncio.wait_for(t, 5)
    finally:
        t.cancel()
        job.procs.discard(proc)
        if proc.returncode is None:
            proc.kill()
    if rc != 0:
        raise FFmpegError("\n".join(tail))


async def ff(rc, args, duration=None, label="⚙️ بعالج"):
    """نسخة للأدوات: بتحدّث رسالة التقدم وبتحوّل الفشل لرسالة مفهومة."""
    try:
        await run_ffmpeg(rc.job, args, duration, rc.pct_cb(label))
    except FFmpegError as e:
        raise UserError("ffmpeg مقدرش يكمّل العملية دي على الملف ده.\n<code>"
                        + esc(e.tail[-500:]) + "</code>") from None


def fmt_ts(sec: float) -> str:
    return f"{float(sec):.3f}"
