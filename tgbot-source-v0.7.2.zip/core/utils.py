"""أدوات مساعدة: تنسيق الأحجام، تنظيف أسماء الملفات، إخفاء الأسرار من اللوج."""
from __future__ import annotations

import html
import logging
import re
import shutil
import time
import unicodedata
from pathlib import Path

START_TIME = time.time()


def esc(s) -> str:
    return html.escape(str(s), quote=False)


def human_size(n) -> str:
    if n is None:
        return "—"
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{int(n)} B" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return "—"


def human_duration(sec) -> str:
    if sec is None:
        return "—"
    sec = int(round(float(sec)))
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def human_elapsed(sec) -> str:
    sec = int(sec)
    m, s = divmod(sec, 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h} س {m:02d} د"
    if m:
        return f"{m} د {s:02d} ث"
    return f"{s} ث"


def human_bitrate(bps) -> str:
    try:
        return f"{float(bps) / 1000:.0f} kbps"
    except (TypeError, ValueError):
        return "—"


# ---------- أسماء الملفات ----------
_BAD = re.compile(r'[\x00-\x1f\x7f/\\:*?"<>|]')
_BIDI = re.compile(r"[\u200e\u200f\u202a-\u202e\u2066-\u2069]")
_DOUBLE_EXT = (".tar.gz", ".tar.bz2", ".tar.xz")
_EXT_OK = re.compile(r"^[A-Za-z0-9]{1,8}$")


def split_ext(name: str):
    low = name.lower()
    for d in _DOUBLE_EXT:
        if low.endswith(d) and len(name) > len(d):
            return name[: -len(d)], name[-len(d):]
    stem, dot, ext = name.rpartition(".")
    if dot and stem and _EXT_OK.match(ext):
        return stem, "." + ext
    return name, ""


def sanitize_filename(name, max_bytes: int = 180, fallback: str = "file") -> str:
    """بيمنع / \\ .. والرموز الخطرة، ويحافظ على العربي والامتداد."""
    name = unicodedata.normalize("NFC", str(name or ""))
    name = _BIDI.sub("", name)
    name = _BAD.sub(" ", name)
    name = re.sub(r"\s+", " ", name).strip(" .")
    if name in ("", ".", ".."):
        return fallback
    stem, ext = split_ext(name)
    budget = max(8, max_bytes - len(ext.encode("utf-8")))
    sb = stem.encode("utf-8")
    if len(sb) > budget:
        stem = sb[:budget].decode("utf-8", "ignore").rstrip()
    return (stem.strip(" .") or fallback) + ext


_TAGS = re.compile(r"\s*[\[\(](?:y2mate[^\]\)]*|savefrom[^\]\)]*|ssyoutube[^\]\)]*|www\.[^\]\)]+|official[^\]\)]*|hd|hq)[\]\)]", re.I)
_JUNK = re.compile(r"^(?:AUD|VID|IMG|PTT|DOC|VOICE|PXL|MVI|DSC)[-_ ]?\d[\w\- ]*$", re.I)


def smart_name(original: str):
    """اقتراح اسم أنضف (من غير امتداد). بيرجع None لو مفيش تحسين مفيد."""
    stem, _ext = split_ext(original)
    if _JUNK.match(stem) or re.fullmatch(r"(?:file|document|audio|video|voice|photo)[_ ]?\d*", stem, re.I):
        return None
    s = _TAGS.sub("", stem)
    s = re.sub(r"\s*\(\d+\)$", "", s)
    s = re.sub(r"\s*-\s*Copy$", "", s, flags=re.I)
    s = s.replace("_", " ")
    if " " not in s.strip() and s.count("-") + s.count(".") >= 2:
        s = s.replace(".", " ").replace("-", " ")
    s = re.sub(r"\s+", " ", s).strip(" .-")
    s = sanitize_filename(s, fallback="")
    if not s or s == stem:
        return None
    return s


def build_final_name(typed: str, original: str, ext_mode: str = "keep") -> str:
    """ext_mode=keep: بيحافظ على امتداد الأصل. custom: الاسم زي ما اتكتب."""
    typed = sanitize_filename(typed, fallback="")
    if not typed:
        return ""
    _stem, orig_ext = split_ext(original)
    if ext_mode == "custom":
        return typed
    _t_stem, t_ext = split_ext(typed)
    if orig_ext and t_ext.lower() == orig_ext.lower():
        return typed
    return sanitize_filename(typed + orig_ext)


# ---------- نظام ----------
def disk_free(path) -> int:
    p = Path(path)
    while not p.exists() and p != p.parent:
        p = p.parent
    return shutil.disk_usage(p).free


def mem_info():
    """(total, available) بالبايت من /proc/meminfo."""
    try:
        d = {}
        for line in Path("/proc/meminfo").read_text().splitlines():
            k, v = line.split(":", 1)
            d[k] = int(v.split()[0]) * 1024
        return d.get("MemTotal"), d.get("MemAvailable")
    except Exception:
        return None, None


def uptime_seconds() -> float:
    return time.time() - START_TIME


# ---------- حماية الأسرار في اللوج ----------
_TOKEN_IN_TEXT = re.compile(r"(?:bot|file/bot)?\d{6,12}:[A-Za-z0-9_-]{30,}")


class SecretFilter(logging.Filter):
    def __init__(self, secrets=()):
        super().__init__()
        self.secrets = [s for s in secrets if s and len(s) >= 8]

    def redact(self, text: str) -> str:
        for s in self.secrets:
            text = text.replace(s, "***")
        return _TOKEN_IN_TEXT.sub("***", text)

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            record.msg = self.redact(record.getMessage())
            record.args = ()
            if record.exc_info:
                record.exc_text = self.redact(logging.Formatter().formatException(record.exc_info))
                record.exc_info = None
        except Exception:
            pass
        return True


def redact_text(text: str, secrets=()) -> str:
    return SecretFilter(secrets).redact(str(text))
