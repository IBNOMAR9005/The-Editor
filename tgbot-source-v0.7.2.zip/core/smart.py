"""الاقتراحات والتحذيرات الذكية بناءً على بيانات الملف. أي اقتراح لوظيفة مش جاهزة بعد مش بيظهر
(بنسأل registry) — فمفيش وعود فاضية."""
from __future__ import annotations

from core import registry as R
from core.utils import human_size, sanitize_filename

LIMIT = 2000 * 1024 ** 2   # حد رفع تليجرام عبر Local Bot API


def hints(kind: str, size: int, probe: dict, name: str, compressed: bool, free: int) -> list:
    out = []
    if size and size >= 0.9 * LIMIT:
        out.append("⚠️ الملف قريب من حد 2GB — أي ناتج أكبر منه مش هينفع يترفع.")
    if size and free and free < size * 3:
        out.append(f"⚠️ المساحة الفاضية ({human_size(free)}) قليلة — العمليات التقيلة ممكن تترفض.")
    if compressed:
        out.append("📸 الصورة وصلت <b>مضغوطة</b> من تليجرام. ابعتها كـ <b>File/Document</b> للجودة الأصلية.")
    if sanitize_filename(name) != name:
        out.append("🧹 اسم الملف فيه رموز غير آمنة — هتتنضّف تلقائيًا عند الحفظ.")
    if probe.get("pdf", {}).get("encrypted"):
        out.append("🔒 الـ PDF محمي بكلمة سر — بعض العمليات هتحتاجها.")
    if not probe.get("ok", True):
        out.append("⚠️ الملف شكله تالف أو بصيغة غريبة — البيانات اللي ظهرت محدودة.")

    # اقتراحات مرتبطة بمراحل جاية: بتشتغل أوتوماتيك أول ما الوظيفة تبقى ready
    h = probe.get("height") or 0
    if kind == "video" and h >= 2160 and R.is_ready("v_compress"):
        out.append("💡 فيديو 4K — للضغط أنا أقترح 1080p أو 720p.")
    if kind == "audio" and probe.get("channels") == 1 and R.is_ready("a_convert"):
        out.append("💡 الصوت مونو أصلًا — مفيش فايدة من ستيريو.")
    if kind == "audio" and probe.get("audio_bitrate") and R.is_ready("a_convert"):
        out.append(f"💡 الـ bitrate الأصلي {probe['audio_bitrate'] // 1000}kbps — مش هقترح أعلى منه.")

    pdf = probe.get("pdf", {})
    if kind == "pdf" and pdf.get("scanned") and R.is_ready("p_ocr"):
        out.append("💡 الـ PDF ده <b>ممسوح ضوئيًا</b> (مفيهوش نص) — أقترح OCR عربي/إنجليزي.")
    if kind == "pdf" and size > 20 * 1024 ** 2 and R.is_ready("p_compress"):
        out.append("💡 الملف تقيل — جرّب الضغط (preset «متوازن» غالبًا مناسب).")
    return out
