"""التخزين: SQLite (إعدادات المستخدم + جلسات الملفات بمعرّفات قصيرة للـ callback_data)
+ حالة الحوار في الذاكرة. callback_data حده 64 بايت، فمبنحطش فيه مسارات أبدًا."""
from __future__ import annotations

import json
import secrets
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_SETTINGS = {
    "notify_boot": True,       # رسالة "البوت اشتغل" عند كل إقلاع
    "clean_chat": True,        # مسح رسايلي اللي بكتب فيها الاسم عشان الشات يفضل نضيف
    "audio_as_player": True,   # الصوت يتبعت كـ Audio player (mp3/m4a) مش document
    "ttl_min": 90,             # مدة صلاحية كروت الملفات قبل ما تتنضف
    # افتراضيات الأدوات (بتتعدّل من ⚙️ إعدادات)
    "a_format": "mp3", "a_bitrate": 192,
    "v_codec": "h264", "v_crf": 24, "v_height": 0, "v_gpu": True,
    "pdf_preset": "ebook", "ocr_lang": "ara+eng",
}


class Store:
    def __init__(self, path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(self.path, check_same_thread=False, timeout=30)
        # DELETE بدل WAL: أأمن على Google Drive (FUSE)
        self._db.execute("PRAGMA journal_mode=DELETE")
        with self._lock:
            self._db.executescript("""
            CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT);
            CREATE TABLE IF NOT EXISTS settings (uid INTEGER, k TEXT, v TEXT, PRIMARY KEY (uid, k));
            CREATE TABLE IF NOT EXISTS sessions (
                ref TEXT PRIMARY KEY, uid INTEGER, payload TEXT, created REAL, used REAL);
            """)
            self._db.commit()

    def _exec(self, sql, args=()):
        with self._lock:
            cur = self._db.execute(sql, args)
            self._db.commit()
            return cur

    # ---- kv ----
    def kv_get(self, key, default=None):
        row = self._exec("SELECT v FROM kv WHERE k=?", (key,)).fetchone()
        return json.loads(row[0]) if row else default

    def kv_set(self, key, value):
        self._exec("INSERT OR REPLACE INTO kv(k,v) VALUES (?,?)", (key, json.dumps(value, ensure_ascii=False)))

    # ---- إعدادات المستخدم ----
    def get_setting(self, uid, key):
        row = self._exec("SELECT v FROM settings WHERE uid=? AND k=?", (uid, key)).fetchone()
        return json.loads(row[0]) if row else DEFAULT_SETTINGS.get(key)

    def set_setting(self, uid, key, value):
        self._exec("INSERT OR REPLACE INTO settings(uid,k,v) VALUES (?,?,?)", (uid, key, json.dumps(value)))

    def all_settings(self, uid) -> dict:
        out = dict(DEFAULT_SETTINGS)
        for k, v in self._exec("SELECT k,v FROM settings WHERE uid=?", (uid,)).fetchall():
            out[k] = json.loads(v)
        return out

    # ---- جلسات الملفات ----
    def new_session(self, uid, payload: dict) -> str:
        ref = secrets.token_urlsafe(6)[:8].replace("-", "x").replace("_", "y")
        now = time.time()
        self._exec("INSERT INTO sessions(ref,uid,payload,created,used) VALUES (?,?,?,?,?)",
                   (ref, uid, json.dumps(payload, ensure_ascii=False), now, now))
        return ref

    def get_session(self, ref, uid=None, touch=True):
        row = self._exec("SELECT uid,payload FROM sessions WHERE ref=?", (ref,)).fetchone()
        if not row or (uid is not None and row[0] != uid):
            return None
        if touch:
            self._exec("UPDATE sessions SET used=? WHERE ref=?", (time.time(), ref))
        data = json.loads(row[1])
        data["_ref"], data["_uid"] = ref, row[0]
        return data

    def update_session(self, ref, **fields):
        cur = self.get_session(ref, touch=False)
        if cur is None:
            return
        cur.pop("_ref", None), cur.pop("_uid", None)
        cur.update(fields)
        self._exec("UPDATE sessions SET payload=?, used=? WHERE ref=?",
                   (json.dumps(cur, ensure_ascii=False), time.time(), ref))

    def drop_session(self, ref):
        self._exec("DELETE FROM sessions WHERE ref=?", (ref,))

    def expired_sessions(self, ttl_seconds):
        cutoff = time.time() - ttl_seconds
        rows = self._exec("SELECT ref,payload FROM sessions WHERE used<?", (cutoff,)).fetchall()
        return [(r, json.loads(p)) for r, p in rows]

    def live_paths(self) -> set:
        paths = set()
        for (p,) in self._exec("SELECT payload FROM sessions").fetchall():
            loc = json.loads(p).get("local")
            if loc:
                paths.add(loc)
        return paths


# ---------- حالة في الذاكرة ----------
@dataclass
class Dialog:
    kind: str                 # "rename" ...
    ref: str
    chat_id: int
    msg_id: int
    expires: float
    data: dict = field(default_factory=dict)


class Dialogs:
    TIMEOUT = 300  # 5 دقايق

    def __init__(self):
        self._d = {}
        self.intent = {}    # uid -> ("rename", expires): المستخدم دوس زرار رئيسي وبعدين هيبعت ملف
        self.section = {}   # uid -> "audio" | "video" | ...

    def set(self, uid, dlg: Dialog):
        self._d[uid] = dlg

    def get(self, uid, kind=None):
        dlg = self._d.get(uid)
        if dlg and dlg.expires < time.time():
            return None
        if dlg and kind and dlg.kind != kind:
            return None
        return dlg

    def clear(self, uid):
        self._d.pop(uid, None)
        self.intent.pop(uid, None)

    def set_intent(self, uid, name):
        self.intent[uid] = (name, time.time() + 600)

    def pop_intent(self, uid):
        it = self.intent.pop(uid, None)
        return it[0] if it and it[1] > time.time() else None

    def sweep(self):
        """بيرجع الحوارات اللي انتهت مهلتها (عشان نعدّل رسايلها) ويمسحها."""
        now = time.time()
        dead = [(u, d) for u, d in self._d.items() if d.expires < now]
        for u, _ in dead:
            self._d.pop(u, None)
        for u in [u for u, (_, e) in self.intent.items() if e < now]:
            self.intent.pop(u, None)
        return dead
