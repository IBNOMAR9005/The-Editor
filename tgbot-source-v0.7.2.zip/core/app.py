"""سياق التطبيق المشترك + حماية whitelist + معلومات النظام."""
from __future__ import annotations

import json
from dataclasses import dataclass, field

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message

import logging

from config import Config
from core.queue import JobQueue
from core.state import Dialogs, Store
from core.utils import disk_free, mem_info, uptime_seconds

log = logging.getLogger("app")


def read_health(cfg: Config) -> dict:
    try:
        return json.loads(cfg.health_file.read_text())
    except Exception:
        return {}


@dataclass
class AppCtx:
    cfg: Config
    store: Store          # إعدادات المستخدم + kv (على Drive لو متوصّل)
    runtime: Store        # جلسات الملفات (محلي)
    queue: JobQueue
    dialogs: Dialogs
    version: str
    server_ok: bool = True
    boot: dict = field(default_factory=dict)

    def sysinfo(self) -> dict:
        h = read_health(self.cfg)
        total, avail = mem_info()
        return {
            "version": self.version, "uptime": uptime_seconds(), "server_ok": self.server_ok,
            "queue": self.queue.snapshot(), "disk_free": disk_free(self.cfg.work),
            "mem_total": total, "mem_avail": avail, "gpu": h.get("gpu"),
            "tools": h.get("tools", {}),
        }


class Whitelist(BaseMiddleware):
    """أي مستخدم مش في ALLOWED_USER_IDS يتتجاهل تمامًا (رقمه بيتسجّل في اللوج بس).
    الاستثناء الوحيد: /id بيرد برقم الحساب عشان تعرف تضيفه."""

    def __init__(self, allowed):
        self.allowed = frozenset(allowed)

    async def __call__(self, handler, event, data):
        user = data.get("event_from_user")
        if user is None:
            return None
        if user.id in self.allowed:
            return await handler(event, data)
        if isinstance(event, Message) and event.text:
            cmd = event.text.split()[0].split("@")[0].lower()
            if cmd == "/id":
                return await handler(event, data)
        log.warning("ignored unauthorized user id=%s", user.id)
        return None
