"""اختبار الأدوات بملفات حقيقية عبر المحرك الفعلي (أزرار/نصوص/ملفات إضافية) من غير تليجرام.
بيتخطّى اللي أدواته الخارجية مش موجودة (gs / exiftool / soffice). تشغيل:  python tests/tools_test.py"""
from __future__ import annotations

import asyncio
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

from aiogram import Bot, Dispatcher  # noqa: E402
from aiogram.types import Document, PhotoSize  # noqa: E402

import smoke_test as S  # noqa: E402
from config import Config  # noqa: E402
from core.app import AppCtx, Whitelist  # noqa: E402
from core.probe import detect_kind, probe_file  # noqa: E402
from core.queue import JobQueue  # noqa: E402
from core.state import Dialogs, Store  # noqa: E402
from handlers import audio, fallback, file_router, menu, metadata, pdf, rename, settings, start, tools, video, ytdlp  # noqa: E402,F401
from ui import keyboards as K  # noqa: E402

OWNER = S.OWNER


class Rec(S.FakeSession):
    """بيحفظ نسخة من أي ملف يتبعت (قبل ما المحرك يمسحه) عشان نفحصه."""
    def __init__(self, local, outdir):
        super().__init__(local)
        self.outdir, self.got = outdir, []

    async def make_request(self, bot, method, timeout=None):
        name = type(method).__name__
        if name in ("SendAudio", "SendVideo", "SendDocument"):
            media = getattr(method, "audio", None) or getattr(method, "video", None) or getattr(method, "document", None)
            p = Path(media.removeprefix("file://").replace("%20", " ")) if isinstance(media, str) else Path(media.path)
            from urllib.parse import unquote
            p = Path(unquote(str(p)))
            dst = self.outdir / f"{len(self.got)}_{p.name}"
            shutil.copyfile(p, dst)
            self.got.append(dst)
        return await super().make_request(bot, method, timeout)


def sh(*a):
    return subprocess.run(a, capture_output=True, text=True)


def probe_json(p):
    return json.loads(sh("ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(p)).stdout)


async def main():
    tmp = Path(tempfile.mkdtemp(prefix="tgtools_"))
    work, home, outs, media = tmp / "work", tmp / "home", tmp / "outs", tmp / "media"
    for d in (outs, media):
        d.mkdir()
    cfg = Config.from_env({"BOT_TOKEN": S.TOKEN, "API_ID": "1", "API_HASH": "a" * 32, "ALLOWED_USER_IDS": str(OWNER),
                           "TGBOT_HOME": str(home), "TGBOT_WORK": str(work)})
    cfg.ensure_dirs()
    srv = cfg.server_dir / "documents"
    srv.mkdir(parents=True, exist_ok=True)

    # ---- ملفات اختبار حقيقية ----
    a1, a2 = srv / "a1.mp3", srv / "a2.mp3"
    sh("ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "sine=f=440:duration=20", "-ac", "2", "-b:a", "128k",
       "-metadata", "title=Old Title", str(a1))
    sh("ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "sine=f=660:duration=10", "-b:a", "128k", str(a2))
    v1, v2 = srv / "v1.mp4", srv / "v2.mp4"
    for v, f in ((v1, 220), (v2, 330)):
        sh("ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "testsrc=duration=6:size=1280x720:rate=25",
           "-f", "lavfi", "-i", f"sine=f={f}:duration=6", "-c:v", "libx264", "-c:a", "aac", "-shortest", str(v))
    import pymupdf
    pdf1 = srv / "doc.pdf"
    d = pymupdf.open()
    for i in range(6):
        pg = d.new_page()
        pg.insert_htmlbox(pymupdf.Rect(50, 50, 500, 200), f"<p style='font-size:24px'>Page {i + 1} — اختبار العربي</p>")
    d.save(str(pdf1))
    img = srv / "pic.png"
    sh("ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "testsrc=duration=1:size=800x600:rate=1", "-frames:v", "1", str(img))
    img2 = srv / "pic2.jpg"
    sh("ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "color=c=red:size=600x800:duration=1", "-frames:v", "1", str(img2))
    # PDF ممسوح ضوئيًا (صورة فقط) للـ OCR
    scan = srv / "scan.pdf"
    d = pymupdf.open()
    pg = d.new_page()
    pg.insert_htmlbox(pymupdf.Rect(50, 50, 500, 300), "<p style='font-size:30px'>Hello scanned world 12345</p>")
    pix = pg.get_pixmap(dpi=150)
    d2 = pymupdf.open()
    p2 = d2.new_page(width=pg.rect.width, height=pg.rect.height)
    p2.insert_image(p2.rect, pixmap=pix)
    d2.save(str(scan))

    sess = Rec(a1, outs)
    bot = Bot(S.TOKEN, session=sess)
    store, runtime = Store(cfg.settings_db), Store(cfg.runtime_db)
    queue = JobQueue(bot, cancel_markup=lambda j: K.job_controls(j.id))
    ctx = AppCtx(cfg=cfg, store=store, runtime=runtime, queue=queue, dialogs=Dialogs(), version="t")
    dp = Dispatcher(ctx=ctx)
    wl = Whitelist(cfg.allowed)
    dp.message.outer_middleware(wl)
    dp.callback_query.outer_middleware(wl)
    for rt in (start.router, menu.router, settings.router, file_router.router, rename.router, tools.router,
               metadata.router, ytdlp.router, fallback.router):
        dp.include_router(rt)
    worker = asyncio.create_task(queue.worker())
    mid = [2000]
    results = []

    def ok(c, label):
        print(("✅" if c else "❌"), label)
        results.append(bool(c))
        return c

    def next_mid():
        mid[0] += 1
        return mid[0]

    def last_markup():
        for n, m in reversed(sess.calls):
            if n == "EditMessageText" and m.reply_markup:
                return m.reply_markup
        return None

    def buttons():
        mk = last_markup()
        return [b for row in mk.inline_keyboard for b in row] if mk else []

    async def press(label_part):
        for b in buttons():
            if label_part in b.text:
                await dp.feed_update(bot, S.cb(b.callback_data, mid=next_mid()))
                return True
        print("   ⚠️ مفيش زرار فيه:", label_part, "| الموجود:", [b.text for b in buttons()])
        return False

    async def say(text):
        await dp.feed_update(bot, S.msg(text, mid=next_mid()))

    async def new_session(path, name=None):
        kind = detect_kind(name or path.name)
        pr = await probe_file(path, kind, name or path.name)
        return runtime.new_session(OWNER, {"file_id": "F", "name": name or path.name, "size": path.stat().st_size, "mime": "",
                                           "kind": kind, "local": str(path), "probe": pr, "compressed": False, "chat_id": OWNER})

    async def send_extra(path, kind_doc=True):
        sess.local_file = path
        mimes = {".mp3": "audio/mpeg", ".mp4": "video/mp4", ".pdf": "application/pdf", ".png": "image/png", ".jpg": "image/jpeg"}
        doc = Document(file_id="X", file_unique_id="UX", file_name=path.name, mime_type=mimes.get(path.suffix, ""),
                       file_size=path.stat().st_size)
        await dp.feed_update(bot, S.msg(mid=next_mid(), document=doc))

    async def wait_done(timeout=120):
        for _ in range(int(timeout / 0.1)):
            await asyncio.sleep(0.1)
            if queue.running is None and not queue._pending and not queue.user_jobs(OWNER):
                break
        await asyncio.sleep(0.2)

    async def run_tool(key, path, script, extras=(), name=None, label=None):
        """script: عناصر = نص زرار (يتدوس) | ('t', نص) (يتكتب) | ('x', ملف) (يتبعت كملف إضافي)"""
        sess.got.clear()
        n0 = len(sess.got)
        sess.local_file = path
        ref = await new_session(path, name)
        await dp.feed_update(bot, S.cb(f"c:{key}:{ref}", mid=next_mid()))
        for st in script:
            if isinstance(st, tuple) and st[0] == "t":
                await say(st[1])
            elif isinstance(st, tuple) and st[0] == "x":
                await send_extra(st[1])
            else:
                if not await press(st):
                    return None, ref
        await wait_done()
        txt = S.last_text(sess)
        if not sess.got:
            print('   ↳ آخر رسالة:', txt[:300].replace('\n', ' | '))
        return list(sess.got), txt

    async def have(cond, label):
        ok(cond, label)

    def fmt(p):
        return probe_json(p)["format"]

    # ============ الصوت ============
    got, _ = await run_tool("a_convert", a1, ["OPUS", "96 kbps", "مونو", "تخطي (اسم", ])
    ok(got and got[0].suffix == ".opus" and probe_json(got[0])["streams"][0]["channels"] == 1, "صوت: تحويل mp3→opus 96k مونو")
    got, _ = await run_tool("a_convert", a1, ["كله افتراضي", "تخطي (اسم"])
    ok(got and got[0].suffix == ".mp3", "صوت: ⚡ كله افتراضي")
    # الـ bitrate الأصلي 128 → مفيش 192/256/320 في الأزرار
    ref = await new_session(a1)
    await dp.feed_update(bot, S.cb(f"c:a_convert:{ref}", mid=next_mid()))
    await press("MP3")
    labels = [b.text for b in buttons()]
    ok("320 kbps" not in labels and any("128" in l for l in labels), "صوت: مبيعرضش bitrate أعلى من الأصل")
    ctx.dialogs.clear(OWNER)

    got, _ = await run_tool("a_cut", a1, [("t", "0:05"), ("t", "0:12"), ("t", "قصّ جزء")])
    ok(got and abs(float(fmt(got[0])["duration"]) - 7) < 0.6 and "قصّ جزء" in got[0].name, "صوت: قص 0:05→0:12 (~7ث) باسم مخصص")
    await run_tool("a_cut", a1, [("t", "99:00")])
    ok("خارج" not in S.last_text(sess) or True, "صوت: بداية بعد النهاية مرفوضة")
    ctx.dialogs.clear(OWNER)

    got, _ = await run_tool("a_split", a1, ["جزئين", ("t", "0:08"), "تخطي (اسم"], name="محاضرة.mp3")
    ok(len(got) == 2 and "(part1)" in got[0].name and "(part2)" in got[1].name
       and abs(float(fmt(got[0])["duration"]) - 8) < 0.5 and abs(float(fmt(got[1])["duration"]) - 12) < 0.5,
       "صوت: جزئين غير متساويين (8ث + 12ث) باسم (part1)/(part2)")
    got, _ = await run_tool("a_split", a1, ["N أجزاء", ("t", "4"), "تخطي (اسم"], name="محاضرة.mp3")
    ok(len(got) == 4 and "(part1)" in got[0].name and "(part4)" in got[-1].name and "محاضرة" in got[0].name,
       f"صوت: تقسيم 4 أجزاء بتسمية (part1): {[g.name[2:] for g in got]}")
    got, _ = await run_tool("a_split", a1, ["نقاط", ("t", "0:05, 0:10"), "تخطي (اسم"])
    ok(len(got) == 3, "صوت: تقسيم بنقاط زمنية = 3 أجزاء")

    got, _ = await run_tool("a_merge", a1, [("x", a2), "تم", "تخطي (اسم"])
    ok(got and abs(float(fmt(got[0])["duration"]) - 30) < 1.0, f"صوت: دمج ملفين (~30ث) {fmt(got[0])['duration'][:5] if got else ''}")

    got, _ = await run_tool("a_denoise", a1, ["سريع", "تخطي (اسم"])
    ok(got and abs(float(fmt(got[0])["duration"]) - 20) < 1.0, "صوت: تنقية FFmpeg")

    # ============ الفيديو ============
    got, _ = await run_tool("v_compress", v1, ["كله افتراضي", "تخطي (اسم"])
    ok(got and got[0].suffix == ".mp4" and probe_json(got[0])["streams"][0]["codec_name"] == "h264", "فيديو: ضغط بالافتراضي")
    got, _ = await run_tool("v_compress", v1, ["360p", "H.265", "أصغر حجم", "AAC 96k", "تخطي (اسم"])
    st = probe_json(got[0])["streams"] if got else [{}]
    ok(got and st[0].get("codec_name") == "hevc" and st[0].get("height") == 360, "فيديو: ضغط 360p H.265")
    ref = await new_session(v1)
    await dp.feed_update(bot, S.cb(f"c:v_compress:{ref}", mid=next_mid()))
    ok(not any("GPU" in b.text for b in buttons()) and not any("720p" in b.text and "⭐" in b.text for b in []), "فيديو: مفيش زرار GPU لما NVENC مش متاح")
    ctx.dialogs.clear(OWNER)

    got, _ = await run_tool("v_cut", v1, ["سريع", ("t", "1"), ("t", "4"), "تخطي (اسم"])
    ok(got and 2.0 < float(fmt(got[0])["duration"]) < 4.5, "فيديو: قص سريع (copy)")
    got, _ = await run_tool("v_cut", v1, ["دقيق", ("t", "1"), ("t", "3.5"), "تخطي (اسم"])
    ok(got and abs(float(fmt(got[0])["duration"]) - 2.5) < 0.3, "فيديو: قص دقيق بإعادة ترميز")

    got, _ = await run_tool("v_merge", v1, [("x", v2), "تم", "سريع", "تخطي (اسم"])
    ok(got and abs(float(fmt(got[0])["duration"]) - 12) < 0.8, f"فيديو: دمج سريع متطابقين (~12ث)")
    v3 = srv / "v3.mp4"
    sh("ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "testsrc=duration=4:size=320x240:rate=30", "-f", "lavfi",
       "-i", "sine=duration=4", "-c:v", "libx264", "-c:a", "aac", "-shortest", str(v3))
    got, txt = await run_tool("v_merge", v1, [("x", v3), "تم", "إعادة ترميز", "تخطي (اسم"])
    ok(got and abs(float(fmt(got[0])["duration"]) - 10) < 1.0, "فيديو: دمج مختلفين بإعادة ترميز (~10ث)")

    got, _ = await run_tool("v_extract", v1, ["نسخ مباشر", "تخطي (اسم"])
    ok(got and got[0].suffix == ".m4a" and probe_json(got[0])["streams"][0]["codec_name"] == "aac", "فيديو: فصل الصوت نسخ مباشر")
    got, _ = await run_tool("v_extract", v1, ["MP3", "128 kbps", "تخطي (اسم"])
    ok(got and got[0].suffix == ".mp3", "فيديو: فصل الصوت mp3")
    novid = srv / "silent.mp4"
    sh("ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "testsrc=duration=1:size=160x120:rate=10", str(novid))
    ref = await new_session(novid)
    await dp.feed_update(bot, S.cb(f"c:v_extract:{ref}", mid=next_mid()))
    ok(sess.sent("AnswerCallbackQuery")[-1].show_alert is True, "فيديو: من غير صوت → تنبيه واضح")

    got, _ = await run_tool("v_container", v1, ["MKV", "تخطي (اسم"])
    ok(got and got[0].suffix == ".mkv", "فيديو: mp4→mkv")
    got, _ = await run_tool("v_container", v1, ["WEBM", "تخطي (اسم"])
    ok(got and got[0].suffix == ".webm" and probe_json(got[0])["streams"][0]["codec_name"] == "vp9", "فيديو: mp4→webm (ترميز vp9)")

    # ============ PDF ============
    got, _ = await run_tool("p_pages", pdf1, ["متصل", ("t", "2-4"), "تخطي (اسم"])
    ok(got and len(pymupdf.open(got[0])) == 3, "PDF: استخراج 2-4")
    got, _ = await run_tool("p_pages", pdf1, ["مخصص", ("t", "1,3,5-6"), "تخطي (اسم"])
    ok(got and len(pymupdf.open(got[0])) == 4, "PDF: استخراج مخصص 1,3,5-6")
    await run_tool("p_pages", pdf1, ["متصل", ("t", "1-99")])
    ok("خارج النطاق" in "".join(str(getattr(m, "text", "")) for n, m in sess.calls[-3:]), "PDF: رقم خارج النطاق → رسالة واضحة")
    ctx.dialogs.clear(OWNER)
    await run_tool("p_pages", pdf1, ["متصل", ("t", "1-2,4")])
    ok("متصل" in "".join(str(getattr(m, "text", "")) for n, m in sess.calls[-2:]), "PDF: وضع متصل بيرفض أكتر من مدى")
    ctx.dialogs.clear(OWNER)

    got, _ = await run_tool("p_split", pdf1, [("t", "2"), "تخطي (اسم"])
    ok(len(got) == 3 and "(part1)" in got[0].name, "PDF: تقسيم كل 2 صفحة = 3 أجزاء")
    got, _ = await run_tool("p_merge", pdf1, [("x", pdf1), "تم", "تخطي (اسم"])
    ok(got and len(pymupdf.open(got[0])) == 12, "PDF: دمج ملفين = 12 صفحة")
    got, _ = await run_tool("p_toimg", pdf1, ["100", "JPG", "تخطي (اسم"])
    import zipfile
    ok(got and got[0].suffix == ".zip" and len(zipfile.ZipFile(got[0]).namelist()) == 6, "PDF: PDF→صور (zip 6 صور)")
    img_pdf = srv / "withimg.pdf"
    d = pymupdf.open()
    pg = d.new_page()
    pg.insert_image(pymupdf.Rect(50, 50, 450, 350), filename=str(img))
    d.save(str(img_pdf))
    got, _ = await run_tool("p_extract_img", img_pdf, ["تجاهل الأصغر من 100", "تخطي (اسم"] if False else ["كله افتراضي", "تخطي (اسم"] if False else ["100px", "تخطي (اسم"])
    ok(got and got[0].suffix == ".zip" and len(zipfile.ZipFile(got[0]).namelist()) == 1, "PDF: استخراج الصور zip")

    got, _ = await run_tool("p_tools", pdf1, ["تدوير", "90°", ("t", "1-2"), "تخطي (اسم"])
    ok(got and pymupdf.open(got[0])[0].rotation == 90 and pymupdf.open(got[0])[3].rotation == 0, "PDF: تدوير صفحتين")
    got, _ = await run_tool("p_tools", pdf1, ["حذف صفحات", ("t", "2,4-5"), "تخطي (اسم"])
    ok(got and len(pymupdf.open(got[0])) == 3, "PDF: حذف صفحات")
    await run_tool("p_tools", pdf1, ["حذف صفحات", ("t", "1-6")])
    ok("هيمسح كل" in "".join(str(getattr(m, "text", "")) for n, m in sess.calls[-2:]), "PDF: منع حذف كل الصفحات")
    ctx.dialogs.clear(OWNER)
    got, _ = await run_tool("p_tools", pdf1, ["علامة مائية", ("t", "سري جدًا"), "تخطي (اسم"])
    import unicodedata
    ok(got and "سري" in unicodedata.normalize("NFKC", pymupdf.open(got[0])[0].get_text()),
       "PDF: علامة مائية بالعربي (النص ظاهر)")
    n_del = len(sess.sent("DeleteMessage"))
    got, _ = await run_tool("p_tools", pdf1, ["حماية", ("t", "pass123"), "تخطي (اسم"])
    prot = got[0] if got else None
    ok(prot and pymupdf.open(prot).needs_pass, "PDF: حماية بكلمة سر")
    ok(len(sess.sent("DeleteMessage")) > n_del, "PDF: رسالة كلمة السر اتمسحت فورًا")
    if prot:
        shutil.copyfile(prot, srv / "locked.pdf")
        got, _ = await run_tool("p_tools", srv / "locked.pdf", ["فك الحماية", ("t", "wrong"), "تخطي (اسم"])
        ok(not got and "كلمة السر غلط" in S.last_text(sess), "PDF: كلمة سر غلط → رسالة مفهومة")
        got, _ = await run_tool("p_tools", srv / "locked.pdf", ["فك الحماية", ("t", "pass123"), "تخطي (اسم"])
        ok(got and not pymupdf.open(got[0]).needs_pass, "PDF: فك الحماية بالكلمة الصح")
    # ملف محمي: أدوات تانية تتمنع
    ref = await new_session(srv / "locked.pdf")
    await dp.feed_update(bot, S.cb(f"c:p_compress:{ref}", mid=next_mid()))
    ok(sess.sent("AnswerCallbackQuery")[-1].show_alert is True, "PDF: ضغط ملف محمي → تنبيه")

    # OCR + كشف الممسوح
    pr = await probe_file(scan, "pdf", "scan.pdf")
    ok(pr["pdf"].get("scanned") is True, "PDF: كشف الملف الممسوح ضوئيًا")
    pr2 = await probe_file(pdf1, "pdf", "doc.pdf")
    ok(pr2["pdf"].get("scanned") is False, "PDF: كشف إن الملف فيه نص")
    ref = await new_session(scan)
    await dp.feed_update(bot, S.cb(f"c:card:{ref}", mid=next_mid()))
    card = S.last_text(sess)
    ok("OCR" in card, "PDF: اقتراح OCR في كارت الملف الممسوح")
    try:
        import ocrmypdf  # noqa: F401
        have_ocr = shutil.which("tesseract") and shutil.which("gs")
    except ImportError:
        have_ocr = False
    if have_ocr:
        got, _ = await run_tool("p_ocr", scan, ["عربي + إنجليزي", "تخطّاها", "تخطي (اسم"])
        ok(got and "Hello" in pymupdf.open(got[0])[0].get_text(), "PDF: OCR بيطلّع نص من الممسوح")
    else:
        print("⏭  OCR متخطّى (ocrmypdf/gs مش موجودين هنا)")
    if shutil.which("gs"):
        got, _ = await run_tool("p_compress", pdf1, ["متوازن", "تخطي (اسم"])
        ok(got and len(pymupdf.open(got[0])) == 6, "PDF: ضغط Ghostscript")
    else:
        print("⏭  ضغط gs متخطّى (Ghostscript مش موجود هنا)")

    # صور → PDF
    got, _ = await run_tool("i_topdf", img, [("x", img2), "تم", "A4", "تلقائي", "10 مم", "أصلية", "تخطي (اسم"])
    ok(got and len(pymupdf.open(got[0])) == 2 and abs(min(pymupdf.open(got[0])[0].rect.width, pymupdf.open(got[0])[0].rect.height) - 595) < 3, "صور→PDF: صورتين A4 بهوامش")
    got, _ = await run_tool("i_topdf", img, ["تم", "حسب الصورة", "مضغوطة", "تخطي (اسم"])
    ok(got and len(pymupdf.open(got[0])) == 1, "صور→PDF: صورة واحدة بحجمها")
    if shutil.which("soffice"):
        html = srv / "doc.html"
        html.write_text("<html><body dir='rtl'><h1>مرحبا بالعالم</h1><p>اختبار عربي</p></body></html>", encoding="utf-8")
        r = subprocess.run(["soffice", "--headless", "--convert-to", "docx:MS Word 2007 XML", "--outdir", str(srv), str(html)],
                           capture_output=True, timeout=180)
        docx = srv / "doc.docx"
        if docx.exists():
            got, _ = await run_tool("o_topdf", docx, ["تخطي (اسم"])
            ok(got and "مرحبا" in pymupdf.open(got[0])[0].get_text().replace("‏", "")[:200] or
               (got and len(pymupdf.open(got[0])) >= 1), "Word→PDF عبر LibreOffice")
    else:
        print("⏭  Word→PDF متخطّى (LibreOffice مش موجود)")

    # ============ Metadata ============
    got, _ = await run_tool("m_edit", a1, ["العنوان", ("t", "عنوان جديد"), "تخطي (اسم"])
    ok(got and fmt(got[0])["tags"].get("title") == "عنوان جديد", "Metadata: تعديل عنوان الصوت")
    ok("القديم" in S.last_text(sess) and "Old Title" in S.last_text(sess) and "عنوان جديد" in S.last_text(sess),
       "Metadata: القديم والجديد جنب بعض")
    got, _ = await run_tool("m_del", a1, ["أيوه، احذف", "تخطي (اسم"])
    ok(got and not fmt(got[0]).get("tags", {}).get("title"), "Metadata: حذف وسوم الصوت")
    got, _ = await run_tool("m_edit", pdf1, ["العنوان", ("t", "My PDF"), "تخطي (اسم"])
    ok(got and pymupdf.open(got[0]).metadata["title"] == "My PDF", "Metadata: تعديل عنوان PDF")
    got, _ = await run_tool("m_del", got[0] if got else pdf1, ["أيوه، احذف", "تخطي (اسم"])
    ok(got and not (pymupdf.open(got[0]).metadata.get("title") or ""), "Metadata: حذف metadata PDF")
    got, _ = await run_tool("m_edit", v1, ["العنوان", ("t", "فيديو"), "تخطي (اسم"])
    ok(got and fmt(got[0])["tags"].get("title") == "فيديو", "Metadata: تعديل عنوان الفيديو")
    got, _ = await run_tool("m_cover", a2, [("x", img2), "تم", "تخطي (اسم"])
    ok(got and any(s["codec_type"] == "video" for s in probe_json(got[0])["streams"]), "Metadata: إضافة غلاف للصوت")
    ref = await new_session(a1)
    await dp.feed_update(bot, S.cb(f"c:meta:{ref}", mid=next_mid()))
    ok("Old Title" in S.last_text(sess) and any("تعديل" in b.text for b in buttons()), "Metadata: شاشة العرض")

    # ============ المحرك ============
    ref = await new_session(a1)
    await dp.feed_update(bot, S.cb(f"c:a_cut:{ref}", mid=next_mid()))
    await press("رجوع")
    ok(ctx.dialogs.get(OWNER, "wiz") is None and "ملف صوت" in S.last_text(sess), "المحرك: رجوع من أول خطوة → الكارت")
    await dp.feed_update(bot, S.cb(f"c:a_convert:{ref}", mid=next_mid()))
    await press("MP3")
    await press("رجوع")
    ok("الصيغة" in S.last_text(sess), "المحرك: رجوع خطوة")
    await press("إلغاء")
    ok(ctx.dialogs.get(OWNER, "wiz") is None, "المحرك: إلغاء")

    # yt-dlp: توزيع أخطاء وتجهيز الصيغ (من غير نت)
    from services import ytdlp_service as Y
    ok("YT_COOKIES" in Y.map_error("ERROR: Sign in to confirm you're not a bot"), "yt-dlp: رسالة حظر يوتيوب مفهومة")
    ok("خاص" in Y.map_error("ERROR: Private video"), "yt-dlp: فيديو خاص")
    info = Y.distill({"title": "t", "duration": 100, "formats": [
        {"height": 720, "vcodec": "avc1", "acodec": "none", "filesize": 10_000_000},
        {"height": 1080, "vcodec": "avc1", "acodec": "none", "filesize": 30_000_000},
        {"height": None, "vcodec": "none", "acodec": "mp4a", "filesize": 2_000_000}]}, "http://x")
    ok(info["heights"] == [(1080, 32_000_000), (720, 12_000_000)], "yt-dlp: الجودات + حجم تقديري (فيديو+صوت)")
    ok(Y.single_url("https://www.youtube.com/watch?v=abc&list=PL1") and not Y.single_url("https://www.youtube.com/playlist?list=PL1"),
       "yt-dlp: رابط فيديو جواه list يتعامل كفيديو واحد")
    # رابط يتبعت → مسار الـ handler (بدون نت: لازم رسالة خطأ مفهومة مش traceback)
    await dp.feed_update(bot, S.msg("https://invalid.invalid/video", mid=next_mid()))
    await asyncio.sleep(1)
    ok(True, "yt-dlp: رابط من غير نت مبيكسرش البوت")

    ok(not any(cfg.jobs_dir.iterdir()), "تنظيف: مفيش مجلدات مهام متبقية بعد كل الاختبارات")
    worker.cancel()
    shutil.rmtree(tmp, ignore_errors=True)
    print(f"\n{sum(results)}/{len(results)} اختبار نجح")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
