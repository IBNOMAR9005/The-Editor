"""Metadata: عرض (القديم/الجديد جنب بعض)، تعديل حقول، حذف الكل، غلاف الصوت. المنطق في services/metadata_service.py."""
from __future__ import annotations

from pathlib import Path

from aiogram import Bot, F, Router
from aiogram.types import CallbackQuery

from core.progress import edit_safe
from core.queue import UserError
from core.utils import esc
from core.wizard import Step, Tool, register
from handlers.common import need_session
from services import metadata_service as M
from ui import keyboards as K

router = Router(name="metadata")


def _fields(s):
    return M.FIELDS.get(s["kind"], [])


# ---------------- شاشة العرض ----------------
@router.callback_query(F.data.startswith("c:meta:"))
async def cb_meta(cb: CallbackQuery, bot: Bot, ctx):
    ref = cb.data.split(":", 2)[2]
    sess = await need_session(cb, ctx, ref)
    if not sess:
        return
    path = Path(sess["local"])
    kind = sess["kind"]
    if not path.is_file():
        return await cb.answer("الملف اتمسح من السيرفر — ابعته تاني.", show_alert=True)
    await cb.answer()

    class _J:   # run_cmd محتاج job.procs بس
        procs: set = set()
    cur = await M.read_meta(_J, path, kind)
    lines = ["🏷️ <b>Metadata</b>", f"<code>{esc(sess['name'])}</code>", ""]
    for k, label in _fields(sess):
        lines.append(f"{label}: <b>{esc(cur[k]) if k in cur else '—'}</b>")
    if not _fields(sess):
        lines.append("<i>النوع ده للعرض والحذف بس.</i>")
    extra = [tuple(x) for x in sess.get("probe", {}).get("extra", [])]
    if kind in ("image", "other"):
        extra = await M.exif_all(_J, path)
    if extra:
        lines += ["", "<b>باقي البيانات:</b>"] + [f"• {esc(k)}: {esc(v)}" for k, v in extra[:12]]
    lines += ["", "ℹ️ الحذف بيمسح بيانات الملف بس — مش محتواه (نص جوه الصفحات/الصورة نفسها)."]
    rows = []
    if _fields(sess):
        rows.append([K.b("✏️ تعديل حقل", f"c:m_edit:{ref}", "primary")])
    if kind == "audio" and sess.get("probe", {}).get("ext") in M.COVER_OK:
        rows.append([K.b("🖼 تغيير الغلاف", f"c:m_cover:{ref}")])
    rows.append([K.b("🧹 حذف كل الـ Metadata", f"c:m_del:{ref}", "danger")])
    rows.append([K.b("↩️ رجوع للكارت", f"c:card:{ref}"), K.b("🗑 إغلاق", f"c:close:{ref}", "danger")])
    await edit_safe(bot, cb.message.chat.id, cb.message.message_id, "\n".join(lines)[:3900], K.kb(*rows))


# ---------------- تعديل ----------------
def _p_val(text, s, p):
    t = text.strip()
    if len(t) > 200:
        raise ValueError("النص طويل (الحد 200 حرف).")
    return "" if t == "-" else t


async def run_edit(rc):
    kind, key, value = rc.sess["kind"], rc.params["field"], rc.params["value"]
    dst = rc.out(rc.src.suffix or ".bin")
    old = await M.read_meta(rc.job, rc.src, kind)
    await M.edit(rc, rc.src, dst, kind, {key: value})
    new = await M.read_meta(rc.job, dst, kind)
    d = M.diff_lines(old, new, kind)
    rc.notes.append("🔄 <b>القديم ← الجديد</b>\n" + ("\n".join(d) if d else "• (مفيش تغيير ظاهر — يمكن القيمة هي نفسها)"))
    return [dst]


register(Tool("m_edit", "✏️ تعديل Metadata", [
    Step("field", "اختار الحقل اللي هتعدّله", cols=2, options=lambda s, p, c: [(l, k) for k, l in _fields(s)]),
    Step("value", lambda s, p, c: f"✍️ اكتب القيمة الجديدة لـ <b>{M.LABELS.get(p['field'], p['field'])}</b>\n"
         "<i>اكتب <code>-</code> لمسح الحقل.</i>", kind="text", parse=_p_val),
], run_edit, suffix=" (edited)"))


# ---------------- حذف ----------------
async def run_del(rc):
    dst = rc.out(rc.src.suffix or ".bin")
    await M.strip(rc, rc.src, dst, rc.sess["kind"], keep_cover=rc.params.get("cover") == "keep")
    rc.notes.append("ℹ️ اتمسحت بيانات الملف (metadata) بس — المحتوى نفسه زي ما هو.")
    return [dst]


register(Tool("m_del", "🧹 حذف Metadata", [
    Step("cover", "🧹 هتتمسح كل بيانات الملف (عنوان، فنان، تواريخ، كاميرا، موقع…).\nتحب الغلاف؟", default="del",
         cols=1, when=lambda p, s: s["kind"] == "audio" and bool(s["probe"].get("has_cover")),
         options=lambda s, p, c: [("🧹 امسح كل حاجة (والغلاف)", "del", "danger"), ("🖼 امسح الوسوم وسيب الغلاف", "keep")]),
    Step("ok", "⚠️ <b>تأكيد الحذف</b> — الناتج هيبقى نسخة جديدة والأصل مش هيتغيّر.", default=None, cols=1,
         options=lambda s, p, c: [("🧹 أيوه، احذف", "yes", "danger")]),
], run_del, suffix=" (clean)"))


# ---------------- غلاف ----------------
async def run_cover(rc):
    if not rc.extras:
        raise UserError("ابعت صورة الغلاف.")
    dst = rc.out(rc.src.suffix)
    await M.set_cover(rc, rc.src, Path(rc.extras[0]["local"]), dst)
    return [dst]


register(Tool("m_cover", "🖼 تغيير الغلاف", [
    Step("files", "🖼 ابعت <b>صورة الغلاف</b> (JPG/PNG)", kind="files", accept=("image",), min_files=1),
], run_cover, suffix=" (cover)"))
