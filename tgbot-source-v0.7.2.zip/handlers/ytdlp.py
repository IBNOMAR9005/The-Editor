"""التحميل من الروابط (yt-dlp): ابعت رابط ← كارت ← فيديو/صوت (أزرار صيغ حقيقية) ← تحميل ← إرسال."""
from __future__ import annotations

import logging

from aiogram import Bot, F, Router
from aiogram.types import CallbackQuery, Message

from core.progress import edit_safe
from core.queue import UserError
from core.utils import esc, human_duration, human_size, sanitize_filename
from core.wizard import Step, Tool, register
from handlers.audio import A
from handlers.common import safe_delete
from services import ytdlp_service as Y
from ui import keyboards as K

log = logging.getLogger("ytdlp")
router = Router(name="ytdlp")


# ---------------- الكارت ----------------
def card_text(info: dict) -> str:
    lines = ["⬇️ <b>تحميل من رابط</b>", f"<b>{esc(info['title'][:120])}</b>"]
    if info.get("uploader"):
        lines.append(f"👤 {esc(info['uploader'][:60])}")
    if info["type"] == "playlist":
        lines.append(f"📚 قايمة تشغيل: <b>{info.get('count', 0)}</b> عنصر (الحد الأقصى للتحميل {Y.MAX_PLAYLIST}).")
    else:
        if info.get("duration"):
            lines.append(f"⏱ {human_duration(info['duration'])}")
        hs = info.get("heights") or []
        if hs:
            lines.append("🎬 الجودات: " + " • ".join(f"{h}p" for h, _s in hs[:6]))
    lines.append("\nاختار النوع 👇")
    return "\n".join(lines)


def card_markup(ref: str, info: dict):
    if info["type"] == "playlist":
        rows = [[K.b("📚 تحميل القايمة", f"c:dl_pl:{ref}", "primary")]]
    else:
        rows = [[K.b("🎬 فيديو", f"c:dl_v:{ref}", "primary"), K.b("🎵 صوت", f"c:dl_a:{ref}", "primary")]]
    rows.append([K.b("🗑 إغلاق", f"c:close:{ref}", "danger")])
    return K.kb(*rows)


async def show_url_card(bot: Bot, ctx, uid: int, ref: str, chat_id: int, msg_id: int):
    sess = ctx.runtime.get_session(ref, uid)
    if not sess:
        return await edit_safe(bot, chat_id, msg_id, "⏰ انتهت صلاحية الرابط — ابعته تاني.", None)
    ctx.dialogs.clear(uid)
    await edit_safe(bot, chat_id, msg_id, card_text(sess["info"]), card_markup(ref, sess["info"]))


@router.message(F.text.regexp(Y.URL_RE), ~F.text.in_(K.MAIN_LABELS), ~F.text.startswith("/"))
async def on_url(msg: Message, bot: Bot, ctx):
    uid = msg.from_user.id
    url = Y.URL_RE.search(msg.text).group(0).rstrip(").,،")
    if ctx.store.get_setting(uid, "clean_chat"):
        await safe_delete(msg)
    status = await bot.send_message(msg.chat.id, "🔎 بقرا الرابط…")
    try:
        info = await Y.fetch_info(url, ctx.cfg.yt_cookies, ctx.cfg.work)
    except UserError as e:
        return await edit_safe(bot, status.chat.id, status.message_id, f"{e}", K.kb([K.b("✖️ إخفاء", "x:close", "danger")]))
    except Exception:
        log.exception("fetch_info failed")
        return await edit_safe(bot, status.chat.id, status.message_id, "❌ حصل خطأ غير متوقع أثناء قراءة الرابط.", None)
    name = sanitize_filename(info["title"], fallback="video") + ".dl"
    ref = ctx.runtime.new_session(uid, {"kind": "url", "url": url, "name": name, "title": info["title"], "info": info,
                                        "local": None, "probe": {}, "size": 0, "mime": ""})
    await show_url_card(bot, ctx, uid, ref, status.chat.id, status.message_id)


@router.callback_query(F.data == "u:ytdlp")
async def cb_update(cb: CallbackQuery, bot: Bot, ctx):
    await cb.answer("بحدّث…")
    await edit_safe(bot, cb.message.chat.id, cb.message.message_id, "🔄 بحدّث yt-dlp… (ممكن ياخد دقيقة)", None)
    try:
        before, after, ok = await Y.update_ytdlp()
    except Exception:
        log.exception("yt-dlp update failed")
        before, after, ok = "؟", "؟", False
    txt = (f"✅ yt-dlp: <code>{esc(before)}</code> ← <code>{esc(after)}</code>" + ("  (كان آخر إصدار)" if before == after else "")
           if ok else "❌ التحديث فشل (النت؟). جرّب تاني.")
    await edit_safe(bot, cb.message.chat.id, cb.message.message_id, txt, K.kb([K.b("✖️ إخفاء", "x:close", "danger")]))


# ---------------- الأدوات ----------------
def _cookies(rc):
    return Y.write_cookies(rc.ctx.cfg.yt_cookies, rc.jobdir)


def _h_label(h, size):
    t = f"{h}p"
    if size:
        t += f" • ~{human_size(size)}" + (" ⚠️ >2GB" if size > Y.LIMIT else "")
    return t


def _h_opts(s, p, c):
    hs = s["info"].get("heights") or []
    opts = [(_h_label(h, sz), h) for h, sz in hs]
    return opts + [("🏆 أفضل جودة متاحة", 0, "primary")]


def _h_default(s, p, c):
    hs = [h for h, _ in (s["info"].get("heights") or [])]
    want = int(c.store.get_setting(s["_uid"], "v_height") or 720) or 720
    ok = [h for h in hs if h <= want]
    return ok[0] if ok else (0 if not hs else hs[-1])


async def run_dl_video(rc):
    h = rc.params.get("height") or None
    ck = _cookies(rc)
    f = await Y.download(rc, rc.sess["url"], "dl", "video", height=h, cookies=ck)
    dst = rc.out(f.suffix)
    f.replace(dst)
    return [dst]


register(Tool("dl_v", "🎬 تحميل فيديو", [
    Step("height", "🎬 اختار <b>الجودة</b> (الحجم تقديري)", options=_h_opts, default=_h_default, cols=1),
], run_dl_video, needs_file=False))


AFMTS = [("MP3", "mp3"), ("M4A (AAC)", "m4a"), ("OPUS", "opus")]


async def run_dl_audio(rc):
    ck = _cookies(rc)
    f = await Y.download(rc, rc.sess["url"], "dl", "audio", afmt=rc.params["fmt"], abr=rc.params.get("abr") or 192, cookies=ck)
    dst = rc.out(f.suffix)
    f.replace(dst)
    return [dst]


register(Tool("dl_a", "🎵 تحميل صوت", [
    Step("fmt", "🎵 اختار <b>الصيغة</b>", cols=3, options=lambda s, p, c: [(l, v) for l, v in AFMTS],
         default=lambda s, p, c: c.store.get_setting(s["_uid"], "a_format") if c.store.get_setting(s["_uid"], "a_format") in ("mp3", "m4a", "opus") else "mp3"),
    Step("abr", "🎚 <b>الـ bitrate</b>", cols=4, default=192, options=lambda s, p, c: [(f"{b}k", b) for b in (128, 192, 256, 320)]),
], run_dl_audio, needs_file=False))


async def run_dl_playlist(rc):
    info, p = rc.sess["info"], rc.params
    ck = _cookies(rc)
    items = info["entries"][: p["count"]]
    for n, it in enumerate(items, 1):
        rc.check_cancel()
        try:
            await rc.say(f"📚 <b>{rc.tool.title}</b>\nالعنصر {n}/{len(items)}: {esc(it['title'][:60])}", True)
            if p["mode"] == "a":
                f = await Y.download(rc, it["url"], f"pl{n}", "audio", afmt="mp3", abr=192, cookies=ck,
                                     label=f"⬇️ [{n}/{len(items)}]")
            else:
                f = await Y.download(rc, it["url"], f"pl{n}", "video", height=720, cookies=ck, label=f"⬇️ [{n}/{len(items)}]")
            dst = rc.jobdir / sanitize_filename(it["title"] + f.suffix, fallback=f"item{n}{f.suffix}")
            if dst.exists():
                dst = rc.jobdir / sanitize_filename(f"{n}. {it['title']}{f.suffix}", fallback=f"item{n}{f.suffix}")
            f.replace(dst)
            await rc.send(dst)
        except UserError as e:
            rc.notes.append(f"⚠️ العنصر {n} ({esc(it['title'][:40])}) اتخطّى:\n{e}")
    return []


register(Tool("dl_pl", "📚 تحميل قايمة", [
    Step("count", lambda s, p, c: f"📚 القايمة فيها {s['info'].get('count', 0)} عنصر. أحمّل كام؟ (حد أقصى {Y.MAX_PLAYLIST})",
         default=5, cols=4, options=lambda s, p, c: [(str(n), n) for n in (3, 5, 10, 25, 50) if n <= max(3, s["info"].get("count", 0))]),
    Step("mode", "اختار النوع", default="a", options=lambda s, p, c: [("🎵 صوت MP3 192k", "a", "primary"), ("🎬 فيديو 720p", "v")]),
], run_dl_playlist, needs_file=False, needs_name=False))
