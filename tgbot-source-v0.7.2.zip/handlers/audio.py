"""أدوات الصوت (تعريفات Tool). المنطق في services/audio_service.py."""
from __future__ import annotations

from pathlib import Path

from core.queue import UserError
from core.wizard import Step, Tool, parse_time, register
from services import audio_service as A
from core.utils import human_duration


def _dur(s):
    return (s.get("probe") or {}).get("duration")


def _set(key):
    return lambda s, p, c: c.store.get_setting(s["_uid"], key)


# ---------------- تحويل ----------------
def _fmt_opts(s, p, c):
    cur = A.fmt_for_ext((s["probe"] or {}).get("ext", ""), "")
    out = []
    for k in A.FORMATS:
        lab = A.LABELS[k] + (" (نفس الصيغة)" if k == cur else "")
        out.append((lab, k, "primary" if k == c.store.get_setting(s["_uid"], "a_format") else None))
    return out


def _br_title(s, p, c):
    _o, src = A.allowed_bitrates(s["probe"], p["fmt"])
    t = "🎚 اختار الـ <b>bitrate</b>"
    return t + (f"\n💡 الأصل ≈ {src} kbps — مش هعرض أعلى منه (مفيش فايدة)." if src else "")


def _br_opts(s, p, c):
    opts, _ = A.allowed_bitrates(s["probe"], p["fmt"])
    return [(f"{b} kbps", b) for b in opts]


def _br_default(s, p, c):
    return A.pick_bitrate(s["probe"], p["fmt"], int(c.store.get_setting(s["_uid"], "a_bitrate") or 192))


def _sr_opts(s, p, c):
    cur = s["probe"].get("sample_rate") or 0
    return [("زي الأصل", 0)] + [(f"{r / 1000:g} kHz", r) for r in A.SAMPLE_RATES if not cur or r < cur]


async def run_convert(rc):
    p = rc.params
    fmt = p["fmt"]
    dst = rc.out(A.FORMATS[fmt][1])
    await A.convert(rc, rc.src, dst, fmt, p.get("bitrate") or 0, p.get("channels") or 0, p.get("sr") or 0,
                    rc.probe.get("duration"))
    if not A.FORMATS[fmt][2] and not rc.probe.get("ext", "") in (".wav", ".flac"):
        rc.notes.append("ℹ️ تحويل لصيغة بدون فقد من ملف مضغوط مبيحسّنش الجودة، بس بيكبّر الحجم.")
    return [dst]


register(Tool("a_convert", "🔁 تحويل الصيغة", [
    Step("fmt", "📦 اختار <b>الصيغة</b>", options=_fmt_opts, default=_set("a_format"), cols=2),
    Step("bitrate", _br_title, options=_br_opts, default=_br_default, cols=4,
         when=lambda p, s: A.FORMATS[p["fmt"]][2]),
    Step("channels", "🔈 <b>القنوات</b>", default=0, when=lambda p, s: s["probe"].get("channels") != 1,
         options=lambda s, p, c: [("زي الأصل", 0), ("مونو", 1), ("ستيريو", 2)]),
    Step("sr", "📻 <b>Sample rate</b>", default=0, options=_sr_opts, cols=3,
         when=lambda p, s: bool(s["probe"].get("sample_rate")) and p["fmt"] != "opus"),
], run_convert))


# ---------------- قص ----------------
def _p_start(text, s, p):
    t = parse_time(text)
    d = _dur(s)
    if d and t >= d:
        raise ValueError(f"البداية بعد نهاية الملف (مدته {human_duration(d)}).")
    return t


def _p_end(text, s, p):
    t = parse_time(text)
    if t <= p.get("start", 0):
        raise ValueError("النهاية لازم تكون بعد البداية.")
    d = _dur(s)
    if d and t > d + 0.5:
        raise ValueError(f"النهاية بعد نهاية الملف (مدته {human_duration(d)}).")
    return min(t, d) if d else t


async def run_cut(rc):
    st = rc.params.get("start", 0.0)
    en = rc.params.get("end") or rc.probe.get("duration")
    if not en:
        raise UserError("مقدرتش أعرف مدة الملف — اكتب النهاية بنفسك.")
    dst = rc.out(rc.src.suffix or ".mp3")
    await A.cut_copy(rc, rc.src, dst, st, en - st)
    return [dst]


register(Tool("a_cut", "✂️ قص جزء", [
    Step("start", lambda s, p, c: "⏱ اكتب <b>البداية</b> — مثلًا <code>1:30</code> أو <code>00:01:30</code> أو <code>90</code>"
         + (f"\n📏 مدة الملف: {human_duration(_dur(s))}" if _dur(s) else ""), kind="text", default=0.0, parse=_p_start),
    Step("end", "⏱ اكتب <b>النهاية</b> (أو تخطي = لحد آخر الملف)", kind="text",
         default=lambda s, p, c: _dur(s), parse=_p_end),
], run_cut, suffix=" (cut)"))


# ---------------- تقسيم ----------------
def _p_n(text, s, p):
    if not text.strip().isdigit() or not 2 <= int(text) <= 50:
        raise ValueError("اكتب رقم من 2 لـ 50.")
    return int(text)


def _p_points(text, s, p):
    pts = [parse_time(x) for x in text.replace("،", ",").split(",") if x.strip()]
    d = _dur(s)
    if not pts or pts != sorted(set(pts)) or pts[0] <= 0 or (d and pts[-1] >= d):
        raise ValueError("اكتب نقاط تصاعدية جوه مدة الملف، مثلًا <code>5:00, 10:30</code>.")
    return pts


async def run_split(rc):
    d = rc.probe.get("duration")
    if not d:
        raise UserError("مقدرتش أعرف مدة الملف عشان أقسّمه.")
    p = rc.params
    mid = [p["cut"]] if p["mode"] == "two" else None
    cuts = [0.0] + ([d * i / p["n"] for i in range(1, p["n"])] if p["mode"] == "n" else mid or p["points"]) + [d]
    outs, ext = [], rc.src.suffix or ".mp3"
    for i in range(len(cuts) - 1):
        rc.check_cancel()
        dst = rc.out(ext, part=i + 1)
        await A.cut_copy(rc, rc.src, dst, cuts[i], cuts[i + 1] - cuts[i], f"🔪 جزء {i + 1}/{len(cuts) - 1}")
        outs.append(dst)
    return outs


register(Tool("a_split", "🔪 تقسيم لأجزاء", [
    Step("mode", "اختار طريقة التقسيم", options=lambda s, p, c: [
        ("✂️ جزئين — أحدد نهاية الأول", "two", "primary"), ("🟰 N أجزاء متساوية", "n"), ("📍 نقاط زمنية أحددها", "t")]),
    Step("cut", lambda s, p, c: "⏱ اكتب <b>نهاية الجزء الأول</b> — مثلًا <code>12:30</code>. الباقي هيبقى الجزء التاني."
         + (f"\n📏 مدة الملف: {human_duration(_dur(s))}" if _dur(s) else ""),
         kind="text", parse=lambda t, s, p: _p_points(t, s, p)[0], when=lambda p, s: p["mode"] == "two"),
    Step("n", "🔢 عدد الأجزاء (2–50)", kind="text", default=2, parse=_p_n, when=lambda p, s: p["mode"] == "n"),
    Step("points", lambda s, p, c: "📍 اكتب نقاط القطع مفصولة بفاصلة — مثلًا <code>5:00, 10:30</code>"
         + (f"\n📏 مدة الملف: {human_duration(_dur(s))}" if _dur(s) else ""),
         kind="text", parse=_p_points, when=lambda p, s: p["mode"] == "t"),
], run_split))


# ---------------- دمج ----------------
async def run_merge(rc):
    sessions = [rc.sess] + rc.extras
    files = [rc.src] + [Path(e["local"]) for e in rc.extras]
    probes = [x.get("probe", {}) for x in sessions]
    fmt = A.fmt_for_ext(files[0].suffix)
    dst = rc.out(A.FORMATS[fmt][1])
    if await A.concat(rc, files, dst, fmt, probes):
        rc.notes.append("ℹ️ الملفات كانت بكودك/إعدادات مختلفة فاتحوّلت لصيغة موحّدة قبل الدمج.")
    return [dst]


register(Tool("a_merge", "🧩 دمج ريكوردات", [
    Step("files", "🧩 ابعت باقي الريكوردات اللي عايز تدمجها", kind="files", accept=("audio",), min_files=1),
], run_merge, suffix=" (merged)"))


# ---------------- تنقية ----------------
async def run_denoise(rc):
    p, pr = rc.params, rc.probe
    fmt = A.fmt_for_ext(pr.get("ext", ""))
    dst = rc.out(A.FORMATS[fmt][1])
    br = A.pick_bitrate(pr, fmt, A.src_kbps(pr) or 192)
    if p["mode"] == "ai":
        await A.denoise_ai(rc, rc.src, dst, fmt, br, pr.get("duration"))
    else:
        await A.ff(rc, ["-i", rc.src, "-map", "0:a:0", "-map_metadata", "0", "-af", A.DENOISE_FF,
                        *A.enc_args(fmt, br), dst], pr.get("duration"), "🎙 بنقّي")
    rc.notes.append("ℹ️ التنقية بتعدّل الصوت (إعادة ترميز). لو النتيجة مش عاجباك جرّب الوضع التاني.")
    return [dst]


register(Tool("a_denoise", "🎙 تنقية الصوت", [
    Step("mode", "اختار نوع التنقية", default="ff", options=lambda s, p, c: [
        ("🧼 سريع (FFmpeg: فلتر + تقليل ضوضاء + توحيد الصوت)", "ff", "primary")]
        + ([] if c.store.kv_get("dfn_failed") else [("🤖 AI (DeepFilterNet — جودة أعلى، أبطأ)", "ai")]), cols=1),
], run_denoise, suffix=" (clean)"))
