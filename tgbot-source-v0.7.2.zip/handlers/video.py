"""أدوات الفيديو (تعريفات Tool). المنطق في services/video_service.py."""
from __future__ import annotations

from pathlib import Path

from core.queue import UserError
from core.utils import human_duration
from core.wizard import Step, Tool, register
from handlers.audio import A, _p_end, _p_start, _set
from services import video_service as V


def gpu_step(extra=None):
    """زرار GPU بيظهر بس لو NVENC اتختبر فعليًا (health.json من bootstrap)."""
    return Step("gpu", "⚡ <b>التشفير</b> (الـ GPU اتجرّب فعليًا واشتغل)",
                default=lambda s, p, c: bool(c.store.get_setting(s["_uid"], "v_gpu")),
                when=lambda p, s: V.gpu_available() and (extra(p, s) if extra else True),
                options=lambda s, p, c: [("⚡ GPU (NVENC) — أسرع", True, "primary"), ("🖥 CPU — توافق أعلى", False)])


def _dur(s):
    return (s.get("probe") or {}).get("duration")


# ---------------- قص ----------------
async def run_cut(rc):
    st = rc.params.get("start", 0.0)
    en = rc.params.get("end") or rc.probe.get("duration")
    if not en:
        raise UserError("مقدرتش أعرف مدة الفيديو — اكتب النهاية بنفسك.")
    precise = rc.params.get("mode") == "precise"
    ext = rc.src.suffix.lower() if rc.src.suffix.lower() in (".mp4", ".mkv", ".mov") else ".mp4"
    dst = rc.out(ext)
    await V.cut(rc, rc.src, dst, st, en - st, precise, bool(rc.params.get("gpu")))
    if not precise:
        rc.notes.append("ℹ️ القص السريع بيقص عند أقرب keyframe فممكن يزيد/ينقص ثواني بسيطة. للدقة الكاملة اختار «دقيق».")
    return [dst]


register(Tool("v_cut", "✂️ قص جزء", [
    Step("mode", "اختار نوع القص", default="fast", options=lambda s, p, c: [
        ("⚡ سريع (بدون إعادة ترميز) — بيقص عند أقرب keyframe", "fast", "primary"),
        ("🎯 دقيق (بإعادة ترميز) — للثانية بس أبطأ", "precise")], cols=1),
    Step("start", lambda s, p, c: "⏱ اكتب <b>البداية</b> — مثلًا <code>1:30</code>"
         + (f"\n📏 مدة الفيديو: {human_duration(_dur(s))}" if _dur(s) else ""), kind="text", default=0.0, parse=_p_start),
    Step("end", "⏱ اكتب <b>النهاية</b> (أو تخطي = لحد آخر الفيديو)", kind="text",
         default=lambda s, p, c: _dur(s), parse=_p_end),
    gpu_step(lambda p, s: p.get("mode") == "precise"),
], run_cut, suffix=" (cut)"))


# ---------------- ضغط ----------------
def _res_opts(s, p, c):
    h = s["probe"].get("height") or 0
    opts = [("زي الأصل", 0)] + [(f"{x}p", x) for x in (1080, 720, 480, 360) if not h or x < h]
    sug = 1080 if h >= 2160 else None
    return [(l + (" ⭐ مقترح" if v == sug else ""), v, "primary" if v == sug else None) for l, v in opts]


def _res_default(s, p, c):
    h = s["probe"].get("height") or 0
    if h >= 2160:
        return 1080
    want = int(c.store.get_setting(s["_uid"], "v_height") or 0)
    return want if (want and (not h or want < h)) else 0


async def run_compress(rc):
    p, pr = rc.params, rc.probe
    dst = rc.out(".mp4")
    await V.compress(rc, rc.src, dst, p.get("height") or 0, p["codec"], p["crf"], p["audio"], bool(p.get("gpu")),
                     pr.get("duration"))
    if dst.stat().st_size >= rc.src.stat().st_size:
        rc.notes.append("⚠️ الناتج أكبر من الأصل أو زيه — الملف كان مضغوط كويس بالفعل. جرّب دقة أقل أو CRF أعلى.")
    return [dst]


register(Tool("v_compress", "🗜 ضغط الفيديو", [
    Step("height", lambda s, p, c: "📐 <b>الدقة</b>" + ("\n💡 فيديو 4K — أقترح 1080p." if (s["probe"].get("height") or 0) >= 2160 else ""),
         options=_res_opts, default=_res_default, cols=3),
    Step("codec", "🎞 <b>الكودك</b>", default=_set("v_codec"), options=lambda s, p, c: [
        ("H.264 — توافق أعلى", "h264", "primary"), ("H.265 — حجم أصغر", "h265")]),
    Step("crf", "🎚 <b>الجودة</b> (CRF: أقل = جودة أعلى)", default=lambda s, p, c: int(c.store.get_setting(s["_uid"], "v_crf") or 24),
         options=lambda s, p, c: [("عالية (20)", 20), ("متوازنة (24)", 24, "primary"), ("أصغر حجم (28)", 28)], cols=3),
    Step("audio", "🔊 <b>الصوت</b>", default=128, options=lambda s, p, c: [
        ("AAC 128k", 128, "primary"), ("AAC 96k", 96), ("نسخ كما هو", "copy")], cols=3),
    gpu_step(),
], run_compress, suffix=" (compressed)"))


# ---------------- دمج ----------------
def _merge_opts(s, p, c):
    probes = [s["probe"]] + [e["probe"] for e in p.get("_extra", [])]
    ok, why = V.merge_compat(probes)
    if ok:
        return [("⚡ سريع بدون ترميز (الملفات متطابقة ✅)", "copy", "primary"), ("🎞 بإعادة ترميز", "re")]
    return [(f"🎞 بإعادة ترميز (الملفات مختلفة: {why})", "re", "primary")]


def _merge_default(s, p, c):
    return _merge_opts(s, p, c)[0][1]


async def run_merge(rc):
    sessions = [rc.sess] + rc.extras
    files = [rc.src] + [Path(e["local"]) for e in rc.extras]
    probes = [x.get("probe", {}) for x in sessions]
    ok, _w = V.merge_compat(probes)
    mode = rc.params.get("mode") or ("copy" if ok else "re")
    if mode == "copy" and not ok:
        mode = "re"
    ext = ".mp4" if mode == "re" else (files[0].suffix or ".mp4")
    dst = rc.out(ext)
    await V.merge(rc, files, dst, probes, mode, bool(rc.params.get("gpu")))
    return [dst]


register(Tool("v_merge", "🧩 دمج فيديوهات", [
    Step("files", "🧩 ابعت باقي الفيديوهات بالترتيب", kind="files", accept=("video",), min_files=1),
    Step("mode", lambda s, p, c: "🔧 <b>طريقة الدمج</b>"
         + ("" if V.merge_compat([s["probe"]] + [e["probe"] for e in p.get("_extra", [])])[0] else
            "\nℹ️ الفيديوهات مختلفة في المواصفات فمينفعش الدمج السريع، هعمل ترميز موحّد."),
         options=_merge_opts, default=_merge_default, cols=1),
    gpu_step(lambda p, s: p.get("mode") == "re"),
], run_merge, suffix=" (merged)"))


# ---------------- فصل الصوت ----------------
def _ext_opts(s, p, c):
    a = s["probe"].get("acodec")
    out = []
    if a in V.COPY_EXT:
        out.append((f"📋 نسخ مباشر ({V.COPY_EXT[a].lstrip('.')}) بدون فقد وبسرعة", "copy", "primary"))
    out += [(A.LABELS[k], k) for k in A.FORMATS]
    return out


def _v_a_br_opts(s, p, c):
    opts, _ = A.allowed_bitrates(s["probe"], p["fmt"])
    return [(f"{b} kbps", b) for b in opts]


async def run_extract(rc):
    p, pr = rc.params, rc.probe
    if p["fmt"] == "copy":
        dst = rc.out(V.COPY_EXT[pr["acodec"]])
        await V.ff(rc, ["-i", rc.src, "-vn", "-map", "0:a:0", "-map_metadata", "0", "-c:a", "copy", dst],
                   pr.get("duration"), "🎧 بفصل الصوت")
    else:
        fmt = p["fmt"]
        dst = rc.out(A.FORMATS[fmt][1])
        await V.ff(rc, ["-i", rc.src, "-vn", "-map", "0:a:0", "-map_metadata", "0",
                        *A.enc_args(fmt, p.get("bitrate") or 0), dst], pr.get("duration"), "🎧 بفصل الصوت")
    return [dst]


def _pre_audio(s, c):
    return None if (s.get("probe") or {}).get("acodec") else "الفيديو ده مفيهوش مسار صوت."


register(Tool("v_extract", "🎧 فصل الصوت", [
    Step("fmt", "🎧 اختار <b>الصيغة</b>", options=_ext_opts, default=lambda s, p, c: "copy" if s["probe"].get("acodec") in V.COPY_EXT else "mp3", cols=1),
    Step("bitrate", "🎚 <b>bitrate</b>", options=_v_a_br_opts, default=lambda s, p, c: A.pick_bitrate(s["probe"], p["fmt"], 192),
         cols=4, when=lambda p, s: p["fmt"] != "copy" and A.FORMATS[p["fmt"]][2]),
], run_extract, suffix=" (audio)", precheck=_pre_audio))


# ---------------- تغيير الصيغة ----------------
def _cont_opts(s, p, c):
    cur = (s["probe"].get("ext") or "").lstrip(".")
    out = []
    for k in V.CONTAINERS:
        cv, ca = V.copy_plan(s["probe"], k)
        tag = "✅ بدون ترميز" if (cv and ca) else "⚠️ هيتعمل ترميز"
        out.append((f"{k.upper()} — {tag}" + (" (الحالية)" if k == cur else ""), k))
    return out


async def run_container(rc):
    t = rc.params["target"]
    dst = rc.out(V.CONTAINERS[t]["ext"])
    await V.remux(rc, rc.src, dst, t, rc.probe.get("duration"))
    return [dst]


register(Tool("v_container", "📦 تغيير الصيغة", [
    Step("target", "📦 اختار <b>الصيغة الجديدة</b>", options=_cont_opts, cols=1),
], run_container, suffix=""))
