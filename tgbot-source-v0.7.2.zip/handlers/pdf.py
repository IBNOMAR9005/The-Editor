"""أدوات الـ PDF (تعريفات Tool). المنطق في services/pdf_service.py و ocr_service و convert_service."""
from __future__ import annotations

from pathlib import Path

from core.queue import UserError
from core.utils import human_size
from core.wizard import Step, Tool, pages_label, parse_ranges, register
from handlers.audio import _set
from services import convert_service as CV, ocr_service as OCR, pdf_service as P


def _n(s):
    return (s.get("probe") or {}).get("pdf", {}).get("pages") or 0


def _enc(s):
    return bool((s.get("probe") or {}).get("pdf", {}).get("encrypted"))


def _pre_open(s, c):
    return "الـ PDF محمي بكلمة سر — افتح 🛠 أدوات PDF وفك الحماية الأول." if _enc(s) else None


# ---------------- ضغط ----------------
def _preset_default(s, p, c):
    pr = s["probe"]
    if pr.get("pdf", {}).get("scanned") and s.get("size", 0) > 5 * 1024 ** 2:
        return "ebook"
    return c.store.get_setting(s["_uid"], "pdf_preset") or "ebook"


async def run_compress(rc):
    dst = rc.out(".pdf")
    await P.compress(rc, rc.src, dst, rc.params["preset"])
    if dst.stat().st_size >= rc.src.stat().st_size:
        dst.unlink()
        import shutil
        shutil.copyfile(rc.src, dst)
        rc.notes.append("⚠️ الضغط مكبّرش الفرق (الملف مضغوط بالفعل) — رجّعتلك الأصلي زي ما هو. جرّب «أصغر حجم».")
    return [dst]


register(Tool("p_compress", "🗜 ضغط PDF", [
    Step("preset", lambda s, p, c: "🗜 اختار <b>مستوى الضغط</b>"
         + ("\n💡 الملف ممسوح ضوئيًا/تقيل — «متوازن» مناسب غالبًا." if s["probe"].get("pdf", {}).get("scanned") else
            f"\n📦 الحجم الحالي: {human_size(s.get('size'))}"),
         default=_preset_default, cols=1, options=lambda s, p, c: [
             ("🟦 متوازن (150dpi) ⭐", "ebook", "primary"), ("🟩 أصغر حجم (72dpi — جودة أقل)", "screen"),
             ("🖨 جودة عالية (300dpi)", "printer")]),
], run_compress, suffix=" (compressed)", precheck=_pre_open))


# ---------------- استخراج صفحات ----------------
def _p_pages(text, s, p):
    return parse_ranges(text, _n(s), contiguous=(p.get("mode") == "range"))


async def run_pages(rc):
    pages = rc.params["pages"]
    dst = rc.out(".pdf", suffix=f" (pages {pages_label(pages)})")
    await P.extract_pages(rc, rc.src, dst, pages)
    return [dst]


register(Tool("p_pages", "📑 استخراج صفحات", [
    Step("mode", lambda s, p, c: f"📑 الملف فيه <b>{_n(s)}</b> صفحة.\nاختار الوضع (وتقدر ترجع تبدّله):",
         default="range", options=lambda s, p, c: [
             ("📏 متصل (مثلًا 5-12)", "range", "primary"), ("🎯 مخصص (مثلًا 1-3,7,10-12)", "custom")]),
    Step("pages", lambda s, p, c: ("✍️ اكتب المدى — مثلًا <code>5-12</code>" if p["mode"] == "range"
                                   else "✍️ اكتب الصفحات — مثلًا <code>1-3,7,10-12</code>"),
         kind="text", parse=_p_pages),
], run_pages, precheck=_pre_open))


# ---------------- تقسيم ----------------
def _p_n(text, s, p):
    if not text.strip().isdigit() or int(text) < 1:
        raise ValueError("اكتب رقم صحيح (عدد الصفحات في كل جزء).")
    n = int(text)
    if _n(s) and -(-_n(s) // n) > 100:
        raise ValueError("ده هيطلع أكتر من 100 جزء — اكتب رقم أكبر.")
    return n


async def run_split(rc):
    outs = await P.split_every(rc, rc.src, rc.params["n"])
    if len(outs) > 8:
        z = P._zip(outs, rc.out(".zip", suffix=" (parts)"))
        for o in outs:
            o.unlink(missing_ok=True)
        rc.notes.append(f"ℹ️ طلع {len(outs)} جزء فاتجمّعوا في zip واحد.")
        return [z]
    return outs


register(Tool("p_split", "✂️ تقسيم PDF", [
    Step("n", lambda s, p, c: f"✂️ كل كام صفحة في الجزء؟ (الملف {_n(s)} صفحة)", kind="text", default=10, parse=_p_n),
], run_split, precheck=_pre_open))


# ---------------- OCR ----------------
async def run_ocr(rc):
    dst = rc.out(".pdf")
    await OCR.ocr_pdf(rc, rc.src, dst, rc.params["lang"], rc.params["skip"] == "skip")
    return [dst]


register(Tool("p_ocr", "🔍 OCR", [
    Step("lang", lambda s, p, c: "🌐 لغة النص" + ("\n💡 الملف ممسوح ضوئيًا (مفيهوش نص) — OCR هو المطلوب." if s["probe"].get("pdf", {}).get("scanned") else ""),
         default=_set("ocr_lang"), cols=1, options=lambda s, p, c: [
             ("🇪🇬🇬🇧 عربي + إنجليزي", "ara+eng", "primary"), ("عربي فقط", "ara"), ("إنجليزي فقط", "eng")]),
    Step("skip", "📄 الصفحات اللي فيها نص بالفعل؟", default="skip", cols=1, options=lambda s, p, c: [
        ("✅ تخطّاها (أسرع وأدق)", "skip", "primary"), ("🔁 OCR لكل الصفحات", "force")]),
], run_ocr, suffix=" (OCR)", precheck=_pre_open))


# ---------------- دمج ----------------
async def run_merge(rc):
    files = []
    for n, s in enumerate([rc.sess] + rc.extras):
        f = Path(s["local"])
        if s["kind"] == "office":
            f = await CV.office_to_pdf(rc, f, n)
        files.append(f)
    dst = rc.out(".pdf")
    await P.merge(rc, files, dst)
    return [dst]


register(Tool("p_merge", "🧩 دمج PDF", [
    Step("files", "🧩 ابعت باقي الملفات (PDF أو Word/PowerPoint) بالترتيب", kind="files", accept=("pdf", "office"), min_files=1),
], run_merge, suffix=" (merged)"))


# ---------------- PDF → صور / استخراج صور ----------------
async def run_toimg(rc):
    return await P.pdf_to_images(rc, rc.src, rc.params["dpi"], rc.params["fmt"])


register(Tool("p_toimg", "🖼 PDF ← صور", [
    Step("dpi", "🔎 <b>الدقة</b>", default=150, cols=3, options=lambda s, p, c: [
        ("72", 72), ("100", 100), ("150 ⭐", 150, "primary"), ("200", 200), ("300", 300)]),
    Step("fmt", "🖼 <b>الصيغة</b>", default="jpg", options=lambda s, p, c: [("JPG (أصغر)", "jpg", "primary"), ("PNG (أوضح)", "png")]),
], run_toimg, suffix="", precheck=_pre_open))


async def run_extract_img(rc):
    return await P.extract_images(rc, rc.src, rc.params["min"])


register(Tool("p_extract_img", "📤 استخراج الصور", [
    Step("min", "📏 تجاهل الصور الصغيرة (أيقونات/زخارف)؟", default=100, cols=1, options=lambda s, p, c: [
        ("🧹 تجاهل الأصغر من 100px ⭐", 100, "primary"), ("تجاهل الأصغر من 200px", 200), ("بدون حد — كل الصور", 0)]),
], run_extract_img, suffix="", precheck=_pre_open))


# ---------------- أدوات: تدوير/حذف/علامة/حماية/فك ----------------
def _op_opts(s, p, c):
    if _enc(s):
        return [("🔓 فك الحماية (محتاج كلمة السر)", "unlock", "primary")]
    return [("🔄 تدوير صفحات", "rotate"), ("🗑 حذف صفحات", "delete"), ("💧 علامة مائية", "watermark"),
            ("🔒 حماية بكلمة سر", "protect"), ("🔓 فك حماية", "unlock")]


def _p_scope(text, s, p):
    t = text.strip().lower()
    if t in ("all", "الكل", "كل", "*"):
        return list(range(1, _n(s) + 1))
    return parse_ranges(text, _n(s))


def _p_delete(text, s, p):
    pages = parse_ranges(text, _n(s))
    if len(set(pages)) >= _n(s):
        raise ValueError("ده هيمسح كل الصفحات! سيب صفحة واحدة على الأقل.")
    return pages


def _p_text(text, s, p):
    t = text.strip()
    if not t or len(t) > 60:
        raise ValueError("اكتب نص من 1 لـ 60 حرف.")
    return t


def _p_pw(text, s, p):
    t = text.strip()
    if not t:
        raise ValueError("اكتب كلمة سر.")
    return t


async def run_tools(rc):
    p, op = rc.params, rc.params["op"]
    src = rc.src
    if op == "watermark":
        dst = rc.out(".pdf", suffix=" (watermark)")
        await P.watermark(rc, src, dst, p["wm"])
    elif op == "rotate":
        dst = rc.out(".pdf", suffix=" (rotated)")
        await P.edit(rc, src, dst, "rotate", p["pages"], angle=p["angle"])
    elif op == "delete":
        dst = rc.out(".pdf", suffix=" (edited)")
        await P.edit(rc, src, dst, "delete", p["pages"])
    elif op == "protect":
        dst = rc.out(".pdf", suffix=" (protected)")
        await P.edit(rc, src, dst, "protect", password=p["pw_new"])
    else:
        dst = rc.out(".pdf", suffix=" (unlocked)")
        await P.edit(rc, src, dst, "unlock", unlock_pw=p["pw_old"])
    return [dst]


register(Tool("p_tools", "🛠 أدوات PDF", [
    Step("op", "🛠 اختار الأداة", options=_op_opts, cols=1,
         default=lambda s, p, c: "unlock" if _enc(s) else None),
    Step("angle", "🔄 زاوية التدوير (باتجاه عقارب الساعة)", default=90, when=lambda p, s: p["op"] == "rotate",
         options=lambda s, p, c: [("90°", 90, "primary"), ("180°", 180), ("270°", 270)], cols=3),
    Step("pages", lambda s, p, c: "📑 أنهي صفحات؟ اكتب مثلًا <code>1-3,7</code> أو <code>الكل</code>"
         + (f"\n(الملف {_n(s)} صفحة)" if _n(s) else ""),
         kind="text", default=lambda s, p, c: list(range(1, _n(s) + 1)), parse=_p_scope, when=lambda p, s: p["op"] == "rotate"),
    Step("pages", lambda s, p, c: f"🗑 اكتب الصفحات اللي تتحذف — مثلًا <code>2,5-7</code> (الملف {_n(s)} صفحة)",
         kind="text", parse=_p_delete, when=lambda p, s: p["op"] == "delete"),
    Step("wm", "💧 اكتب نص العلامة المائية (بيتحط في نص كل صفحة)", kind="text", parse=_p_text,
         when=lambda p, s: p["op"] == "watermark"),
    Step("pw_new", "🔒 اكتب <b>كلمة السر</b> الجديدة\n<i>(هتتمسح رسالتك فورًا من الشات)</i>", kind="text", parse=_p_pw,
         when=lambda p, s: p["op"] == "protect"),
    Step("pw_old", "🔓 اكتب <b>كلمة السر</b> الحالية للملف\n<i>(هتتمسح رسالتك فورًا من الشات)</i>", kind="text", parse=_p_pw,
         when=lambda p, s: p["op"] == "unlock"),
], run_tools, suffix=""))


# ---------------- Word/PPT → PDF ----------------
async def run_topdf(rc):
    tmp = await CV.office_to_pdf(rc, rc.src, 0)
    dst = rc.out(".pdf")
    tmp.replace(dst)
    return [dst]


register(Tool("o_topdf", "📄 تحويل لـ PDF", [], run_topdf))


# ---------------- صور → PDF ----------------
async def run_imgs(rc):
    files = [rc.src] + [Path(e["local"]) for e in rc.extras]
    p = rc.params
    dst = rc.out(".pdf", suffix=f" ({len(files)} images)" if len(files) > 1 else "")
    await CV.images_to_pdf(rc, files, dst, p["size"], p.get("orient", "auto"), p.get("margin", 0), p["quality"])
    return [dst]


register(Tool("i_topdf", "📄 صور ← PDF", [
    Step("files", "🖼 ابعت باقي الصور بالترتيب (أو دوس تم لو الصورة دي بس)", kind="files", accept=("image",), min_files=0),
    Step("size", "📐 <b>حجم الصفحة</b>", default="a4", options=lambda s, p, c: [
        ("A4 ⭐", "a4", "primary"), ("Letter", "letter"), ("حسب الصورة", "fit")], cols=3),
    Step("orient", "↔️ <b>الاتجاه</b>", default="auto", when=lambda p, s: p["size"] != "fit", options=lambda s, p, c: [
        ("تلقائي ⭐", "auto", "primary"), ("طولي", "portrait"), ("عرضي", "landscape")], cols=3),
    Step("margin", "▫️ <b>الهوامش</b>", default=0, when=lambda p, s: p["size"] != "fit", options=lambda s, p, c: [
        ("بدون", 0), ("10 مم", 10, "primary"), ("20 مم", 20)], cols=3),
    Step("quality", "🎚 <b>الجودة</b>", default="orig", options=lambda s, p, c: [
        ("🏆 أصلية (بدون فقد)", "orig", "primary"), ("🗜 مضغوطة (أصغر حجم)", "small")], cols=1),
], run_imgs, suffix=""))
