"""محرك الأدوات: أي Tool معرّف في core.wizard.TOOLS بيشتغل هنا بنفس الشكل:
أزرار الكارت ← خطوات (اختيار/نص/ملفات/اسم الناتج) ← مهمة في الطابور ← إرسال النتيجة.
كل خطوة فيها «تخطي» و«كله افتراضي» و«رجوع» و«إلغاء»."""
from __future__ import annotations

import asyncio
import logging
import shutil
import time
from pathlib import Path

from aiogram import Bot, F, Router
from aiogram.filters import Filter
from aiogram.types import CallbackQuery, Message

from core.probe import detect_kind, probe_file
from core.progress import Reporter, edit_safe, ticker
from core.queue import Job, UserError
from core.sender import send_file
from core.smart import LIMIT
from core.state import Dialog, Dialogs
from core.utils import disk_free, esc, human_elapsed, human_size, sanitize_filename, split_ext
from core.wizard import TOOLS, RunCtx, Step, val
from handlers.common import drop_session_files, need_session, safe_delete
from ui import keyboards as K

log = logging.getLogger("tools")
router = Router(name="tools")

NAME_STEP = Step("name", "✍️ <b>اسم الملف الناتج</b>\nاكتب الاسم اللي عايزه، أو اضغط <b>تخطي</b> وهسمّيه اسم افتراضي ذكي.",
                 kind="name")
EXPIRED = "⏰ الشاشة دي انتهت صلاحيتها — افتح الأداة تاني من الكارت."


def steps_of(tool):
    return list(tool.steps) + ([NAME_STEP] if tool.needs_name else [])


def _next(steps, idx, params, sess):
    while idx < len(steps):
        s = steps[idx]
        if s.when is None or s.when(params, sess):
            return idx
        idx += 1
    return None


def _fill_defaults(steps, idx, params, sess, ctx):
    """بيملّا الافتراضيات من idx لحد أول خطوة مفيهاش افتراضي (أو خطوة الاسم). بيرجّع index الوقوف."""
    while True:
        i = _next(steps, idx, params, sess)
        if i is None:
            return len(steps)
        s = steps[i]
        if s.kind not in ("choice", "text"):
            return i
        d = val(s.default, sess, params, ctx)
        if d is None:
            return i
        params[s.key] = d
        idx = i + 1


def _default_name(tool, sess):
    return split_ext(sess["name"])[0] + tool.suffix


def _list_files(sess, extras):
    lines = [f"1. <code>{esc(sess['name'])}</code> <i>(اللي بعتّه)</i>"]
    for n, e in enumerate(extras, 2):
        lines.append(f"{n}. <code>{esc(e['name'])}</code>")
    return "\n".join(lines)


async def show_back(bot, ctx, uid, ref, chat_id, msg_id):
    sess = ctx.runtime.get_session(ref, uid)
    if sess and sess.get("kind") == "url":
        from handlers import ytdlp
        return await ytdlp.show_url_card(bot, ctx, uid, ref, chat_id, msg_id)
    from handlers import file_router
    await file_router.show_card(bot, ctx, uid, ref, chat_id, msg_id)


# ---------------- فتح أداة ----------------
async def open_tool(bot, ctx, uid, ref, key, chat_id, msg_id) -> str | None:
    sess = ctx.runtime.get_session(ref, uid)
    tool = TOOLS[key]
    if tool.precheck:
        err = tool.precheck(sess, ctx)
        if err:
            return err
    ctx.dialogs.set(uid, Dialog("wiz", ref, chat_id, msg_id, time.time() + Dialogs.TIMEOUT,
                                {"tool": key, "params": {}, "idx": 0, "hist": [], "opts": [], "extra": [], "chosen": {}}))
    await render(bot, ctx, uid)
    return None


async def render(bot: Bot, ctx, uid: int):
    dlg = ctx.dialogs.get(uid, "wiz")
    if not dlg:
        return
    sess = ctx.runtime.get_session(dlg.ref, uid)
    if not sess:
        return await edit_safe(bot, dlg.chat_id, dlg.msg_id, EXPIRED, None)
    d = dlg.data
    tool = TOOLS[d["tool"]]
    steps = steps_of(tool)
    params = d["params"]
    params["_extra"] = [e for e in (ctx.runtime.get_session(r, uid, touch=False) for r in d["extra"]) if e]
    i = _next(steps, d["idx"], params, sess)
    if i is None:
        return await launch(bot, ctx, uid)
    d["idx"] = i
    dlg.expires = time.time() + Dialogs.TIMEOUT
    step, ref = steps[i], dlg.ref
    lines = [f"<b>{tool.title}</b>"]
    lines += [f"• {esc(t)}" for _k, t in sorted(d["chosen"].items())]
    lines += ["", val(step.title, sess, params, ctx)]
    if step.hint:
        lines.append(step.hint)
    rows = []
    dflt = val(step.default, sess, params, ctx)

    if step.kind == "choice":
        opts = val(step.options, sess, params, ctx) or []
        d["opts"] = [o[1] for o in opts]
        d["labels"] = [o[0] for o in opts]
        btns = [K.b(o[0], f"w:{ref}:{n}", o[2] if len(o) > 2 else None) for n, o in enumerate(opts)]
        rows += K._chunk(btns, step.cols)
    elif step.kind == "files":
        lines += ["", _list_files(sess, params["_extra"])]
        lines.append("📥 ابعت الملفات دلوقتي <b>بالترتيب</b> (الترتيب = ترتيب الإرسال)…")
        have = len(params["_extra"])
        if have >= step.min_files:
            rows.append([K.b(f"✅ تم — كمّل ({have + 1} ملف)", f"w:{ref}:s", "success")])
        if have:
            rows.append([K.b("🗑 شيل آخر ملف", f"w:{ref}:u")])
    elif step.kind == "text":
        lines.append("✍️ اكتب القيمة وابعتها." + (f" <i>(الافتراضي: {esc(dflt)})</i>" if dflt is not None else ""))
    elif step.kind == "name":
        lines.append(f"<i>الاسم الافتراضي: {esc(_default_name(tool, sess))}</i>")

    ctl = []
    if step.kind == "name":
        ctl.append(K.b("⏭ تخطي (اسم افتراضي)", f"w:{ref}:s", "success"))
    elif step.kind in ("choice", "text") and dflt is not None:
        ctl.append(K.b("⏭ تخطي (الافتراضي)", f"w:{ref}:s"))
    if step.kind in ("choice", "text"):
        probe_params = dict(params)
        stop = _fill_defaults(steps, i, probe_params, sess, ctx)
        if stop > i and sum(1 for st in steps[i:] if st.kind in ("choice", "text")) > 1:
            ctl.append(K.b("⚡ كله افتراضي", f"w:{ref}:d", "primary"))
    if ctl:
        rows.append(ctl)
    rows.append([K.b("↩️ رجوع", f"w:{ref}:b"), K.b("✖️ إلغاء", f"w:{ref}:x", "danger")])
    await edit_safe(bot, dlg.chat_id, dlg.msg_id, "\n".join(lines), K.kb(*rows))


def _advance(d, step_idx, key, value, shown):
    d["hist"].append(step_idx)
    d["params"][key] = value
    d["chosen"][step_idx] = shown
    d["idx"] = step_idx + 1


# ---------------- أزرار الكارت → فتح الأداة ----------------
def _is_tool_cb(data: str) -> bool:
    parts = (data or "").split(":")
    return len(parts) == 3 and parts[0] == "c" and parts[1] in TOOLS


@router.callback_query(F.data.func(_is_tool_cb))
async def cb_open(cb: CallbackQuery, bot: Bot, ctx):
    _c, key, ref = cb.data.split(":")
    if not await need_session(cb, ctx, ref):
        return
    err = await open_tool(bot, ctx, cb.from_user.id, ref, key, cb.message.chat.id, cb.message.message_id)
    await cb.answer(err, show_alert=True) if err else await cb.answer()


# ---------------- أزرار الخطوات ----------------
@router.callback_query(F.data.startswith("w:"))
async def cb_wizard(cb: CallbackQuery, bot: Bot, ctx):
    _w, ref, act = cb.data.split(":", 2)
    uid = cb.from_user.id
    dlg = ctx.dialogs.get(uid, "wiz")
    if not dlg or dlg.ref != ref:
        return await cb.answer(EXPIRED, show_alert=True)
    sess = ctx.runtime.get_session(ref, uid)
    if not sess:
        return await cb.answer(EXPIRED, show_alert=True)
    d, tool = dlg.data, TOOLS[dlg.data["tool"]]
    steps = steps_of(tool)
    params = d["params"]
    i = d["idx"]
    step = steps[i]

    if act == "x":
        for r in d["extra"]:
            drop_session_files(ctx, r)
        ctx.dialogs.clear(uid)
        await show_back(bot, ctx, uid, ref, dlg.chat_id, dlg.msg_id)
        return await cb.answer("اتلغت")
    if act == "b":
        if not d["hist"]:
            for r in d["extra"]:
                drop_session_files(ctx, r)
            ctx.dialogs.clear(uid)
            await show_back(bot, ctx, uid, ref, dlg.chat_id, dlg.msg_id)
            return await cb.answer()
        back = d["hist"].pop()
        d["idx"] = back
        for j in range(back, len(steps)):
            params.pop(steps[j].key, None)
            d["chosen"].pop(j, None)
        await render(bot, ctx, uid)
        return await cb.answer()
    if act == "d":
        stop = _fill_defaults(steps, i, params, sess, ctx)
        for j in range(i, min(stop, len(steps))):
            if steps[j].key in params:
                d["hist"].append(j)
                d["chosen"][j] = f"{steps[j].key}: {params[steps[j].key]}"
        d["idx"] = stop
        await render(bot, ctx, uid)
        return await cb.answer("اتطبّقت الافتراضيات ⚡")
    if act == "u" and step.kind == "files":
        if d["extra"]:
            drop_session_files(ctx, d["extra"].pop())
        await render(bot, ctx, uid)
        return await cb.answer()
    if act == "s":
        if step.kind == "name":
            params["name"] = None
            d["idx"] = i + 1
        elif step.kind == "files":
            if len(d["extra"]) < step.min_files:
                return await cb.answer(f"محتاج على الأقل {step.min_files} ملف زيادة.", show_alert=True)
            _advance(d, i, step.key, list(d["extra"]), f"{len(d['extra']) + 1} ملف")
        else:
            dv = val(step.default, sess, params, ctx)
            if dv is None:
                return await cb.answer("الخطوة دي مفيهاش قيمة افتراضية — اكتب القيمة.", show_alert=True)
            _advance(d, i, step.key, dv, f"{step.key}: {dv}")
        await render(bot, ctx, uid)
        return await cb.answer()
    if act.isdigit() and step.kind == "choice":
        n = int(act)
        if n >= len(d["opts"]):
            return await cb.answer()
        _advance(d, i, step.key, d["opts"][n], d["labels"][n])
        await render(bot, ctx, uid)
        return await cb.answer()
    await cb.answer()


# ---------------- نص (قيم / اسم) ----------------
class WizText(Filter):
    async def __call__(self, message: Message, ctx) -> bool:
        if not message.from_user:
            return False
        dlg = ctx.dialogs.get(message.from_user.id, "wiz")
        if not dlg:
            return False
        steps = steps_of(TOOLS[dlg.data["tool"]])
        return dlg.data["idx"] < len(steps) and steps[dlg.data["idx"]].kind in ("text", "name")


@router.message(F.text, ~F.text.startswith("/"), ~F.text.in_(K.MAIN_LABELS), WizText())
async def on_wiz_text(msg: Message, bot: Bot, ctx):
    uid = msg.from_user.id
    dlg = ctx.dialogs.get(uid, "wiz")
    sess = ctx.runtime.get_session(dlg.ref, uid)
    if not sess:
        ctx.dialogs.clear(uid)
        return await msg.reply(EXPIRED)
    d, tool = dlg.data, TOOLS[dlg.data["tool"]]
    steps = steps_of(tool)
    i = d["idx"]
    step = steps[i]
    secret = step.key.startswith("pw")
    if secret or ctx.store.get_setting(uid, "clean_chat"):
        await safe_delete(msg)
    try:
        if step.kind == "name":
            value = sanitize_filename(msg.text, fallback="")
            if not value:
                raise ValueError("الاسم ده مش صالح (فاضي أو رموز ممنوعة). اكتب اسم تاني.")
            d["params"]["name"] = value
            d["idx"] = i + 1
        else:
            value = step.parse(msg.text, sess, d["params"]) if step.parse else msg.text.strip()
            _advance(d, i, step.key, value, f"{step.key}: {'••••' if secret else msg.text.strip()[:40]}")
    except ValueError as e:
        return await msg.answer(f"⚠️ {e}")
    await render(bot, ctx, uid)


# ---------------- ملفات إضافية (دمج / صور → PDF) ----------------
async def try_add_extra(bot: Bot, ctx, uid: int, new_ref: str, chat_id: int, status_id: int) -> bool:
    dlg = ctx.dialogs.get(uid, "wiz")
    if not dlg:
        return False
    steps = steps_of(TOOLS[dlg.data["tool"]])
    i = dlg.data["idx"]
    if i >= len(steps) or steps[i].kind != "files":
        return False
    step, new = steps[i], ctx.runtime.get_session(new_ref, uid)
    if new["kind"] not in step.accept:
        drop_session_files(ctx, new_ref)
        await edit_safe(bot, chat_id, status_id, "⚠️ نوع الملف ده مش مناسب للأداة دي. ابعت الأنواع المطلوبة بس.", None)
        await asyncio.sleep(4)
        try:
            await bot.delete_message(chat_id, status_id)
        except Exception:
            pass
        return True
    dlg.data["extra"].append(new_ref)
    try:
        await bot.delete_message(chat_id, status_id)
    except Exception:
        pass
    await render(bot, ctx, uid)
    return True


# ---------------- تشغيل ----------------
async def launch(bot: Bot, ctx, uid: int):
    dlg = ctx.dialogs.get(uid, "wiz")
    tool = TOOLS[dlg.data["tool"]]
    params, extras, ref = dlg.data["params"], list(dlg.data["extra"]), dlg.ref
    ctx.dialogs.clear(uid)
    await submit(bot, ctx, uid, ref, tool, params, extras, dlg.chat_id, dlg.msg_id)


async def _send_output(rc: RunCtx, path: Path):
    size = path.stat().st_size
    if size > LIMIT:
        raise UserError(f"الناتج ({human_size(size)}) أكبر من حد تليجرام <b>2GB</b>. جرّب إعدادات أصغر "
                        "(جودة أقل / دقة أقل) أو قسّمه.")
    kind = detect_kind(path.name)
    probe = await probe_file(path, kind, path.name) if kind in ("audio", "video") else {}
    settings = rc.ctx.store.all_settings(rc.uid)
    prefer = rc.ctx.store.kv_get("send_mode")

    def render(el):
        return (f"⬆️ <b>{rc.tool.title}</b>\nجاري رفع «{esc(path.name[:60])}» ({human_size(size)})…\n⏱ {human_elapsed(el)}\n"
                f"<i>الملفات الكبيرة بتاخد دقايق — مفيش progress حقيقي من السيرفر.</i>")

    async with ticker(rc.rep, render, interval=4.0):
        mode = await send_file(rc.bot, rc.chat_id, path, kind, probe, settings, prefer)
    if mode != prefer:
        rc.ctx.store.kv_set("send_mode", mode)
    rc.outs.append((path.name, size))
    path.unlink(missing_ok=True)   # نفضّي المساحة فورًا


async def submit(bot, ctx, uid, ref, tool, params, extra_refs, chat_id, msg_id):
    async def run(job: Job):
        sess = ctx.runtime.get_session(ref, uid)
        if not sess:
            raise UserError("الكارت انتهت صلاحيته — ابعت الملف تاني 📎")
        extras = [e for e in (ctx.runtime.get_session(r, uid) for r in extra_refs) if e]
        if len(extras) != len(extra_refs):
            raise UserError("واحد من الملفات الإضافية انتهت صلاحيته — ابدأ من الأول.")
        total = 0
        if tool.needs_file:
            for s in [sess] + extras:
                p = Path(s.get("local") or "")
                if not p.is_file():
                    raise UserError("الملف اتمسح من السيرفر (تنظيف تلقائي للمساحة) — ابعته تاني وهتلاقيه بيتحمّل بسرعة.")
                total += p.stat().st_size
            free = disk_free(ctx.cfg.work)
            if free < total * 2:
                raise UserError(f"المساحة الفاضية ({human_size(free)}) مش كفاية للعملية دي (محتاج ~2× حجم الملفات). "
                                "جرّب بعد التنظيف التلقائي أو أعد تشغيل الجلسة.")
        jobdir = ctx.cfg.jobs_dir / job.id
        jobdir.mkdir(parents=True, exist_ok=True)
        job.add_cleanup(lambda: shutil.rmtree(jobdir, ignore_errors=True))
        rep = Reporter(bot, chat_id, msg_id, markup=K.job_controls(job.id))
        rc = RunCtx(bot=bot, ctx=ctx, job=job, tool=tool, sess=sess, extras=extras,
                    params={**params, "_extra": extras}, jobdir=jobdir, rep=rep, chat_id=chat_id,
                    send_hook=_send_output)
        await rep.update(f"⚙️ <b>{tool.title}</b>\nبدأت…", force=True)
        outs = await tool.run(rc)
        for o in outs or []:
            await rc.send(Path(o))
        if not rc.sent:
            raise UserError("العملية خلصت من غير ما تطلع ملف. جرّب إعدادات تانية.")
        lines = [f"✅ <b>{tool.title}</b> — تمت"]
        shown = rc.outs[:6]
        lines += [f"📦 <code>{esc(n)}</code> • {human_size(s)}" for n, s in shown]
        if len(rc.outs) > 6:
            lines.append(f"… و{len(rc.outs) - 6} ملف تاني")
        if total and len(rc.outs) == 1 and not extras:
            new, old = rc.outs[0][1], total
            if old:
                lines.append(f"📉 {human_size(old)} ← {human_size(new)} ({(new - old) * 100 / old:+.0f}%)")
        lines.append(f"⏱ {human_elapsed(time.monotonic() - rc.t0)}")
        lines += [f"\n{n}" for n in rc.notes]
        mk = K.after_job(ref) if sess.get("kind") != "url" else K.kb([K.b("✖️ إخفاء", "x:close", None)])
        await rep.update("\n".join(lines), mk, force=True)

    job = Job(user_id=uid, chat_id=chat_id, msg_id=msg_id, title=tool.title, run=run)
    pos = await ctx.queue.submit(job)
    if pos == 0:
        await edit_safe(bot, chat_id, msg_id, f"⚙️ <b>{tool.title}</b>\nبدأت…", K.job_controls(job.id))
