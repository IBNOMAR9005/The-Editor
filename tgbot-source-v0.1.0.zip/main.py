"""نقطة تشغيل البوت. أكواد الخروج: 0 = إيقاف نضيف، 3 = إعدادات غلط (من غير إعادة تشغيل)، 4 = السيرفر المحلي فشل."""
from __future__ import annotations

import asyncio
import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from aiogram import Bot, Dispatcher  # noqa: E402
from aiogram.client.default import DefaultBotProperties  # noqa: E402
from aiogram.client.session.aiohttp import AiohttpSession  # noqa: E402
from aiogram.client.telegram import TelegramAPIServer  # noqa: E402
from aiogram.enums import ParseMode  # noqa: E402
from aiogram.types import BotCommand  # noqa: E402

from config import Config, ConfigError  # noqa: E402
from core import boot, server  # noqa: E402
from core.app import AppCtx, Whitelist  # noqa: E402
from core.cleanup import cleanup_loop  # noqa: E402
from core.queue import JobQueue  # noqa: E402
from core.state import Dialogs, Store  # noqa: E402
from core.utils import SecretFilter  # noqa: E402
from handlers import audio, fallback, file_router, menu, metadata, pdf, rename, settings, start, tools, video, ytdlp  # noqa: E402
from ui import keyboards as K  # noqa: E402

log = logging.getLogger("main")


def setup_logging(cfg: Config):
    cfg.logs_dir.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s", "%H:%M:%S")
    flt = SecretFilter(cfg.secret_values())
    handlers = [logging.StreamHandler(sys.stdout),
                RotatingFileHandler(cfg.logs_dir / "bot.log", maxBytes=2_000_000, backupCount=2, encoding="utf-8")]
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    for h in handlers:
        h.setFormatter(fmt)
        h.addFilter(flt)
        root.addHandler(h)
    logging.getLogger("aiogram.event").setLevel(logging.WARNING)


async def amain() -> int:
    try:
        cfg = Config.from_env()
    except ConfigError as e:
        print("⛔ الإعدادات فيها مشكلة:\n" + str(e), flush=True)
        return 3
    cfg.ensure_dirs()
    setup_logging(cfg)
    version = (ROOT / "VERSION").read_text().strip() if (ROOT / "VERSION").exists() else "dev"
    log.info("starting tgbot v%s | allowed users: %d", version, len(cfg.allowed))

    ok = await asyncio.to_thread(server.ensure_running, cfg, 90)
    if not ok:
        log.error("local Bot API server did not become ready\n%s", server.server_log_tail(cfg))
        print("❌ السيرفر المحلي مش بيرد. آخر اللوج:\n" + server.server_log_tail(cfg), flush=True)
        return 4

    store, runtime = Store(cfg.settings_db), Store(cfg.runtime_db)
    session = AiohttpSession(api=TelegramAPIServer.from_base(cfg.server_url, is_local=True), timeout=7200)
    bot = Bot(cfg.bot_token, session=session, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    me = await bot.get_me()
    log.info("connected as @%s via local server", me.username)

    queue = JobQueue(bot, cancel_markup=lambda j: K.job_controls(j.id))
    ctx = AppCtx(cfg=cfg, store=store, runtime=runtime, queue=queue, dialogs=Dialogs(), version=version,
                 server_ok=True, boot=boot.detect_boot(cfg))
    queue.on_change = lambda: boot.write_hb(cfg, "running", boot.current_jobs(ctx))

    dp = Dispatcher(ctx=ctx)
    wl = Whitelist(cfg.allowed)
    dp.message.outer_middleware(wl)
    dp.callback_query.outer_middleware(wl)
    # الترتيب مهم: start (فيه /id) ← الأزرار الرئيسية ← الإعدادات ← الملفات ← التسمية ← أي نص تاني
    for r in (start.router, menu.router, settings.router, tools.router, metadata.router, ytdlp.router,
              file_router.router, rename.router, fallback.router):
        dp.include_router(r)

    await bot.delete_webhook(drop_pending_updates=True)  # بعد أي انقطاع: مبنعيدش تنفيذ رسايل قديمة
    await bot.set_my_commands([
        BotCommand(command="start", description="القايمة الرئيسية"),
        BotCommand(command="help", description="❓ قدرات البوت"),
        BotCommand(command="cancel", description="إلغاء العملية الحالية"),
        BotCommand(command="id", description="رقم حسابك"),
    ])

    tasks = [asyncio.create_task(c, name=n) for n, c in (
        ("queue", queue.worker()), ("cleanup", cleanup_loop(ctx)),
        ("heartbeat", boot.heartbeat_loop(ctx)), ("watchdog", boot.watchdog_loop(bot, ctx)),
        ("dialogs", _sweep_dialogs(bot, ctx)))]
    await boot.announce_startup(bot, ctx)
    log.info("ready ✅")
    try:
        await dp.start_polling(bot, allowed_updates=["message", "callback_query"], polling_timeout=30)
    finally:
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        boot.write_hb(cfg, "clean")
        await bot.session.close()
        log.info("stopped cleanly")
    return 0


async def _sweep_dialogs(bot, ctx):
    from core.progress import edit_safe
    while True:
        await asyncio.sleep(30)
        for _uid, dlg in ctx.dialogs.sweep():
            await edit_safe(bot, dlg.chat_id, dlg.msg_id, "⏰ انتهت مهلة الإدخال — ابعت الملف تاني لو لسه عايز.", None)


if __name__ == "__main__":
    try:
        sys.exit(asyncio.run(amain()))
    except KeyboardInterrupt:
        sys.exit(0)
